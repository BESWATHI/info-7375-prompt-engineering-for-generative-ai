# FRICTIONAL — OrderTrail final project pitch video (Smit Patel, INFO 7375)

Dated log of effort, per `prerequisites/frictional.md`. Claude organised the factual entries from the
Claude Code session of 2026-10-10/11; each one matches the files and logs named under it. The
reflection paragraphs were drafted with Codex from those entries and are pending my review: I will
edit them so they say what I actually thought before submitting. Pending decisions are marked as such.

Nothing is committed yet (the `youtube/` folders are untracked in the course repo), so the evidence
is file paths, logs and timestamps, not commit hashes.

---

## 2026-10-10 (morning) — picking a tool for the pitch video

- **Working on:** turning my 8-beat OrderTrail pitch script (each beat with a "Picture:" note) into a video.
- **I tried:** asked Claude Code whether it had a "brutalist.art" skill. It didn't see one until I pointed
  it at the `~/Developer/brutalist.art` folder; the toolkit's 33 skills live there, not in Claude's skill list.
- **I decided:** to use the `cc-explainer` skill, even though Claude recommended `ai-explainer` and warned
  cc-explainer is built around a Claude Code session, not a pitch.
- **Friction:** the CC interface templates were missing from my local toolkit. Claude found my copy was
  45 commits behind GitHub; it stashed my local `package-lock.json` change and fast-forwarded to get them.
- **Why I chose cc-explainer / what I expected:** I chose cc-explainer because I wanted to turn my script into a finished video using the toolkit I had available. I expected the result to follow my eight pitch beats and show the ideas in my “Picture:” notes. The outcome showed that I needed to pay closer attention to what the skill was designed to produce: its focus on a recorded coding session did not fit the pitch I wanted to present.
- **Evidence:** toolkit at `b21f625`; `git stash` entry "local package-lock before cc-explainer pull".

## 2026-10-10 — the real Claude Code session (first version only)

- **I tried:** cc-explainer requires a real recorded session, so I agreed to build OrderTrail's "first piece"
  for real: synthetic order/delivery CSVs, a mismatch check, and a pytest.
- **Friction:** the `claude` CLI on my Mac wasn't logged in ("Not logged in", then "OAuth session expired").
  I had to run `claude auth login` myself before the session could run.
- **What happened:** turn 1 built the files and both tests passed. My own check (`verify1.sh`) showed the
  data was fasteners and packaging, not construction, and a wrong-material delivery was not flagged. Turn 2
  fixed both; Claude also caught its own "rebar supplier selling 2x6s" mistake. My probe was caught after the fix.
- **Claude's contribution:** ran both turns from the prompts I approved, wrote and ran the two verify scripts (`verify1.sh`, `verify2.sh`), and logged everything.
- **What I noticed about trusting passing tests:** Both tests passed in the first turn, but my check still found a wrong-material delivery that was not flagged. Passing tests only showed that the cases covered by those tests worked. They did not prove that the data matched my construction context or that the mismatch check covered the problem I cared about. Checking a concrete example exposed the gap and gave us a specific issue to fix.
- **Evidence:** `youtube/cc-ordertrail-pitch/SESSION.md`, `session/verify1.out`, `session/verify2.out`,
  `learning-artifacts/ordertrail-first-piece/`.

## 2026-10-10 — first version rendered (cc-explainer), then rejected

- **What happened:** Claude built a 6 min 57 s cc-explainer video (21 beats) around the session, after
  12 render passes to clear the toolkit's visual (Gate V) and typography (GATE T) checks.
- **My review:** I watched it and rejected it. My words at the time: *"i dont like what ever you generated …
  show files in python … all looks bad so please see my patch and create a video again."* The video was
  about the code session, not my pitch, and the terminal screens didn't show my "Picture:" ideas.
- **What I did:** asked for a different video skill that shows my pitch as I wrote it.
- **What I wanted the video to feel like instead:** I wanted viewers to understand the construction delivery problem and how OrderTrail would help. The visuals needed to follow my script and “Picture:” notes, with simple scenes that supported the narration. The first version spent too much attention on the coding session and terminal screens. Rejecting it helped me make the intended audience and purpose clearer.
- **Evidence:** `youtube/cc-ordertrail-pitch/final/cc-ordertrail-pitch.mp4`, `BUILD-LOG.md` (gate record).

## 2026-10-10 (evening) — remake with show-tell

- **I tried:** Claude chose the `show-tell` skill: one simple isometric drawing per beat, 1–3 word labels,
  the voice explains. My script is read **word for word**; each of my 8 beats is split at sentence breaks
  into 2–3 drawings taken from my "Picture:" notes. No code or terminal on screen.
- **Friction:** the skill forbids drawing people, so the idle crew became hard hats on a pallet and the two
  readers became a clipboard and a laptop. Five render passes to clear the checks (pale kraft boxes failed
  contrast and got dark plinths; handwriting scribbles were read as too-small text; some drawings landed
  too late in their beat).
- **Claude's contribution:** split the script into beats, drew all scenes in Manim, ran renders and checks,
  and read frames from every beat before the final.
- **Does this version match what I pictured? Anything I'd still change:** The show-tell approach is closer to the direction I requested because it uses drawings from my “Picture:” notes and keeps the code and terminal off screen. The hard hats, clipboard and laptop are compromises made to fit the skill’s restrictions. I still need to watch the final version in full with sound before saying whether the pacing, substitutions and narration match what I pictured.
- **Evidence:** `youtube/show-tell-ordertrail-pitch/` — `beat_sheet.json`, `scenes.py`, `_qc/REPORT.md`, `TYPECHECK.md`.

## 2026-10-11 — added "Where AI comes in"

- **I tried:** asked Claude to add a section on where AI is used in the project and how it helps.
- **What happened:** I didn't write this text; Claude drafted three beats in my voice, consistent with my
  "code calculates, Claude explains" rule: (1) Claude suggests how spreadsheet columns map to orders,
  deliveries and invoices, and I confirm; (2) Claude writes alerts in plain language citing the records;
  (3) Claude Code helps me plan, generate synthetic data and draft tests, and I review every change.
  Inserted after beat 5.
- **Decision (2026-10-11):** the column-mapping idea was not in my original pitch, so the first AI scene now presents it as "one possible extension" that I would confirm, not a committed feature (re-voiced and re-rendered). Whether it becomes a real feature is still open.
- **Do I keep it, and is this how I actually plan to use AI?** The AI section should describe what I actually intend to build. The rule “code calculates, Claude explains” gives me a clear boundary: the reconciliation logic should determine mismatches, while AI can help explain results using the underlying records. Column mapping is an additional proposal from Claude, rather than a feature from my original pitch. Before keeping it, I need to decide whether it fits the project scope and make clear that any suggested mapping requires my confirmation. Until then, I describe it as a possible extension, which is what the video now says.
- **Evidence:** `make_sheet.py` (beats BAI1–BAI3), `FACTCHECK.md` row 7, `final/show-tell-ordertrail-pitch.mp4`.

## Human and AI contributions (summary)

- **Mine:** the project idea and the friend's problem behind it; the full pitch script and every "Picture:"
  note; choosing cc-explainer; logging in the CLI; rejecting the first video and saying why; asking for the
  AI section; the final decision to submit.
- **Claude's:** finding and updating the toolkit; running the recorded session; both videos' beat sheets,
  drawings, audio and renders; drafting the AI section text; this log's structure.
- **What I accepted, changed, or rejected from Claude's work:** I accepted Claude’s help with the toolkit, prototype, rendering and checks. I asked for corrections when the synthetic data and mismatch behavior did not fit the construction problem. I rejected the first video because it did not communicate my pitch, and requested a remake based on my script and visual notes. I asked for the AI section, but still need to review its wording and decide whether the added column-mapping proposal belongs in the project. Technical checks helped improve the output; my review determined whether it served the purpose.

## What I understand now / still don't

- I understand why choosing the right workflow matters before generating an artifact. A coding-session explainer and a project pitch have different purposes, even when both use the same project. I also understand that passing tests and visual checks answer limited questions: I still need to check realistic mismatch cases and judge whether the video communicates my idea. I can explain the intended division between code that calculates and AI that explains, but the column-mapping feature and the final wording of the AI section are still unresolved. I also need to complete the final video review and submission records before treating the work as finished.

