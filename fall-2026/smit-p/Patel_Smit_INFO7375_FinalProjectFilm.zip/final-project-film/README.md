# OrderTrail — Final Project Pitch Film

- **Student:** Smit Patel
- **Course:** INFO 7375 — Prompt Engineering for Generative AI
- **Working title:** OrderTrail — a material order tracker for small construction companies
- **Target role:** Backend software engineer (the pitch is aimed at an engineering hiring manager and shows backend work: Python REST APIs, data pipelines, dashboards)
- **Runtime:** 4 min 20 s (260.0 s), 1920×1080, `show-tell-ordertrail-pitch.mp4`

## Contents

| File | What it is |
|---|---|
| `show-tell-ordertrail-pitch.mp4` | the rendered film |
| `PROJECT-BRIEF.md` | one page: the seven questions, then *exists today* / *will exist* |
| `beat_sheet.json` | narration and visual plan (26 beats) |
| `BUILD-PROMPT.md` | the prompts and commands that rebuild the film |
| `SOURCES.md` | what I used, what I made, what Claude contributed, licences |
| `FRICTIONAL.md` | dated log of the work |
| `REVIEW.md` | machine checks, review decisions, my watch-through |
| `FACTCHECK.md` | external claims checked |
| `SESSION.md` | the real Claude Code session from the first version of the film (the prototype "first piece"; not shown in this film) |
| `gate-reports/` | toolkit gates: Gate V visual QC, GATE T typography, layout audit, verified master record |

## How to rebuild

Needs the `brutalist.art` toolkit (revision `b21f625`) set up with `./setup --install`. Full steps in
`BUILD-PROMPT.md`. In short, from the reel folder that holds `make_sheet.py` and `scenes.py`:

```bash
python3 make_sheet.py
python3 /path/to/brutalist.art/runtime/scripts/generate_audio_kokoro.py "$PWD"
/path/to/brutalist.art/art run   "$PWD" --height 1080
python3 /path/to/brutalist.art/runtime/scripts/type_check.py "$PWD"
/path/to/brutalist.art/art final "$PWD" --height 1080 --out "$PWD/final"
```

Narration: local Kokoro voice `am_onyx` (synthetic; disclosed in `SOURCES.md`). No paid services.
