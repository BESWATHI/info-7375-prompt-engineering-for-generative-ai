# SESSION — cc-ordertrail-pitch

The real Claude Code session this video reconstructs. Every terminal block in `beat_sheet.json`
is checked against this file (REAL-SESSION LAW). Raw logs (`session/cycle*.jsonl`) and every file
version Claude wrote (`session/snapshots/`) are kept locally.

- **Date:** 2026-10-10, 11:41 EDT
- **Where:** `learning-artifacts/ordertrail-first-piece/` in the course repo (empty folder at start)
- **Claude Code:** 2.1.296, headless (`claude -p`), model `claude-opus-5-5`, two turns in one
  session (`cddfc573-e60d-4102-8b91-cbe6bebbc617`; turn 2 resumed it)
- **Tools allowed:** `Read`, `Write`, `Edit`, `Bash(python3:*)`, `Bash(ls:*)`
- **Flags trimmed on screen:** `--allowedTools … --output-format stream-json --verbose`
  (they only restrict tools and format the log; prompts are shown verbatim)

---

## Turn 1 — the ask

```text
$ claude -p "Make synthetic purchase order and delivery CSVs for 20 orders with one planted quantity mismatch. Write a check that flags mismatches, and a pytest proving it flags exactly the planted order."
```

Tool calls (in order; two compound `Bash` calls were refused by the permission fence and Claude
re-issued them as single commands):

```text
⏺ Bash(ls -la)                                   # empty folder
⏺ Read(AGENTS.md)
⏺ Write(generate_data.py)
⏺ Write(reconcile.py)
⏺ Write(tests/test_reconcile.py)
⏺ Bash(python3 generate_data.py)
  ⎿  Wrote 20 orders and 22 deliveries to …/data
⏺ Bash(python3 -m pytest -v tests)
  ⎿  tests/test_reconcile.py::test_flags_exactly_the_planted_order PASSED
     tests/test_reconcile.py::test_corrected_delivery_reconciles_cleanly PASSED
     2 passed
⏺ Bash(python3 reconcile.py)
  ⎿  Exit code 1
     PO-1013: ordered 308, delivered 304 (-4)
```

Key lines Claude wrote (`reconcile.py`, turn 1):

```python
def find_quantity_mismatches(po_path: Path, delivery_path: Path) -> list[dict]:
    delivered[row["po_id"]] += int(row["qty_delivered"])
    want, got = ordered.get(po_id, 0), delivered.get(po_id, 0)
    if want != got:
```

Data: suppliers `Acme Fasteners`, `Northwind Metals`, `Harbor Plastics`, `Delta Packaging`;
SKUs `BOLT-M6`, `NUT-M6`, `WASHER-8`, `BRKT-L2`, `PANEL-A4`, `CRATE-S`. Planted: `PO-1013` short 4.
Split shipments `PO-1005`, `PO-1017` (sum correctly).

Claude's closing line (verbatim): `I built the data, the check and the tests, and both tests pass.
The check flags only the planted order: PO-1013: ordered 308, delivered 304 (-4).`

Turn time: 54.3 s · 4,967 output tokens.

## Verify 1 — my commands, not Claude's ✓ (`session/verify1.sh`)

```text
$ python3 -m pytest -q tests
2 passed in 0.00s
$ cut -d, -f2,3 data/purchase_orders.csv | sort -u | head -6
Acme Fasteners,BOLT-M6
Acme Fasteners,BRKT-L2
Acme Fasteners,PANEL-A4
Delta Packaging,BRKT-L2
Delta Packaging,PANEL-A4
Delta Packaging,WASHER-8
# probe: swap PO-1001's delivery to the wrong material, same quantity
['PO-1013']
```

**What I caught:** (1) the tests pass, but the data is fasteners and packaging, not a construction
site; (2) a delivery of the wrong material at the right quantity is not flagged. The check only
compares quantities.

## Turn 2 — the correction

```text
$ claude -p "A delivery of the wrong material at the right quantity passes your check. And these suppliers aren't construction. Use construction materials, and flag SKU mismatches too." --resume cddfc573
```

```text
⏺ Write(generate_data.py)
⏺ Write(reconcile.py)
⏺ Edit(reconcile.py)  ×3
⏺ Write(tests/test_reconcile.py)
⏺ Edit(generate_data.py)  ×2
⏺ Bash(python3 generate_data.py)
⏺ Bash(python3 -m pytest -v tests)
  ⎿  test_flags_exactly_the_planted_orders PASSED
     test_wrong_material_at_right_quantity_is_flagged PASSED
     test_corrected_deliveries_reconcile_cleanly PASSED
     3 passed in 0.01s
⏺ Bash(python3 reconcile.py)
⏺ Read(data/purchase_orders.csv)
```

Claude, mid-turn (verbatim): `The supplier and material were picked independently, so the data has
a rebar supplier selling 2x6s and a drywall distributor selling cement. I'm tying each material to
its supplier.`

```text
⏺ Edit(generate_data.py)  ×2
⏺ Bash(python3 generate_data.py)
⏺ Bash(python3 -m pytest -q tests)
  ⎿  3 passed in 0.01s
⏺ Bash(python3 reconcile.py)
  ⎿  Exit code 1
     PO-1008 [sku, quantity]: ordered 170 PLY-34-CDX, delivered 0 (-170); wrong material: 170 OSB-716-4X8
     PO-1013 [quantity]: ordered 135 REBAR-4-20, delivered 131 (-4)
```

Key diff (`reconcile.py`, turn 1 → turn 2):

```diff
-def find_quantity_mismatches(po_path: Path, delivery_path: Path) -> list[dict]:
+def find_mismatches(po_path: Path, delivery_path: Path) -> list[dict]:
-            delivered[row["po_id"]] += int(row["qty_delivered"])
+            delivered[row["po_id"]][row["sku"]] += int(row["qty_delivered"])
+        wrong_material = {s: q for s, q in sorted(by_sku.items()) if s != want_sku}
+        got_qty = by_sku.get(want_sku, 0)
+        if wrong_material:
+            issues.append("sku")
+        if got_qty != want_qty:
+            issues.append("quantity")
```

Data now: five suppliers, one per trade (`Ridgeline Lumber Co.`, `Bayside Rebar Supply`,
`Summit Aggregates & Cement`, `Northgate Masonry Supply`, `Harborview Drywall Distributors`).
Planted: `PO-1013` rebar short 4; `PO-1008` full quantity of OSB instead of CDX plywood.

Turn time: 104.2 s · 11,851 output tokens.

## Verify 2 — my commands (`session/verify2.sh`)

```text
$ python3 -m pytest -q tests
3 passed in 0.01s
$ python3 reconcile.py
PO-1008 [sku, quantity]: ordered 170 PLY-34-CDX, delivered 0 (-170); wrong material: 170 OSB-716-4X8
PO-1013 [quantity]: ordered 135 REBAR-4-20, delivered 131 (-4)
# my probe again: PO-1001's delivery swapped to the wrong block size (CMU-8 → CMU-12)
['PO-1001', 'PO-1008', 'PO-1013']
```

My probe is now caught, and the two planted orders are the only flags on the clean data.
Python 3.12.7, pytest 7.4.4.
