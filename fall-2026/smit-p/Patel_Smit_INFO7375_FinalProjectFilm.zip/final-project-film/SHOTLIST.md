# SHOTLIST — show-tell-tripmate-pitch

32 beats · all drawn (Manim, show-tell kit) · 0 cards · 0 slates. Question column = which of the assignment's seven questions the beat answers.

| Beat | Question | Drawing | Why not a card |
|---|---|---|---|
| B01 | 1 | Four objects rise: a bed, a folded map, a blog page, a calculator; a road below ends in a question-mark pin. | a drawing carries the idea; the voice explains |
| B02 | 1 | The word 'TripMate' lands over a road; a small car drives along it to a pin. | a drawing carries the idea; the voice explains |
| B03 | 1 | Six input pills land on a form card: start, destination, dates, travelers, budget, interests. | a drawing carries the idea; the voice explains |
| B04A | 1 | Four travel modes in a row (car, bus, train, plane), each with a cost bar and a time bar; one gets a check 'fits budget'; labelled 'constructed'. | a drawing carries the idea; the voice explains |
| B04B | 1 | Three hotel cards land; two get checks and reason tags, one gets a cross; a budget bar with 'suggest a change'. | a drawing carries the idea; the voice explains |
| B04C | 1 | Interest pills (beaches, forts, veg food) feed a three-day plan, mixed icons per day; labelled 'example'. | a drawing carries the idea; the voice explains |
| B04D | 1 | Three area circles of pins; a clock with 'open hours'; a line between stops with 'travel time'; a plate 'meals'. | a drawing carries the idea; the voice explains |
| B04 | 1 | A long road splits at two bed pins into Day 1, Day 2, Day 3; small break dots appear; label 'road trip'. | a drawing carries the idea; the voice explains |
| B05 | 1 | Four deliverables land: a repo crate, an app window, a test check, an eval report binder. | a drawing carries the idea; the voice explains |
| B06 | 1 | Two shelves fill with solid blocks, 'core' and 'also'; a page 'full list' lands. | a drawing carries the idea; the voice explains |
| B07 | 2 | Left: a folded map with a cursor adding a pin ('you add'). Right: a road with a dashed search ring and a pin ('you pick'). | a drawing carries the idea; the voice explains |
| B08 | 2 | Three plan days under check gates; reason cards hang from the stops. | a drawing carries the idea; the voice explains |
| B09 | 2 | Two pins, Ahmedabad and Goa, joined by a road; a span '1,036 km'; '12.7 h driving'; a car drives; caption 'real route · OSRM · 2026-10-23'. | a drawing carries the idea; the voice explains |
| B10 | 2 | The same road splits into three days with two bed pins; labels '5 h limit' and '3 days'; labelled 'constructed'. | a drawing carries the idea; the voice explains |
| B11 | 3 | A suitcase and a car key on the ground ('traveller'). | a drawing carries the idea; the voice explains |
| B12 | 3 | A sixty-second ring sweeps; an app window fills with plan rows and a 'why' card; labelled 'constructed · mock-up'. | a drawing carries the idea; the voice explains |
| B13 | how | A split stage: 'AI plans' on the left, 'code checks' on the right. | a drawing carries the idea; the voice explains |
| B14 | how | A request page becomes a structured card; a question bubble; tool blocks 'fares', 'hotels', 'places' light in turn. | a drawing carries the idea; the voice explains |
| B15 | how | A server stack; four check boxes; three pass, the fourth gets a cross and a loop arrow sends it back to 'repair'. | a drawing carries the idea; the voice explains |
| B16 | how | Three tags drop onto three plan rows: verified, estimated, AI suggestion. | a drawing carries the idea; the voice explains |
| B17 | how | Chat bubbles; the plan shows a 'preview' with the changed day highlighted; a save check lands. | a drawing carries the idea; the voice explains |
| B18 | 4 | Five skill blocks light in a row. | a drawing carries the idea; the voice explains |
| B19 | 4 | A grid of twenty small trip cards fills; some get a mark; a 'tests' binder and an 'eval report' page land. | a drawing carries the idea; the voice explains |
| B20 | 5 | Bins 'In' and 'Out'; blocks drop into In; a payment card in Out gets a cross. | a drawing carries the idea; the voice explains |
| B21 | 5 | Three day cards in a 'First' row; a 'closed' sign on one, an overflowing budget bar on another; both get flags; 'test passes'. | a drawing carries the idea; the voice explains |
| B22 | 6 | Three data crates: 'places' arrives solid; 'flight prices' and 'hotel prices' are dashed outlines with '?'. | a drawing carries the idea; the voice explains |
| B23 | 6 | A 'flight API' tag and a 'hotel API' tag plug into the gaps; an 'estimate' label on a price row; twenty cards get coverage ticks. | a drawing carries the idea; the voice explains |
| B24 | 7 | A road with a car and a suitcase; two blocks 'show' and 'learn' balance on a beam. | a drawing carries the idea; the voice explains |
| B25 | 7 | Pile one, 'already have': blocks stack up; a repo crate 'README links'. | a drawing carries the idea; the voice explains |
| B26 | 7 | Pile two, 'learning': five blocks stack beside the first. | a drawing carries the idea; the voice explains |
| B27 | 7 | Three solid pages 'pitch', 'brief', 'route sample'; ghost outlines 'will build' below. | a drawing carries the idea; the voice explains |
| BOUT | outro | Title restate and the author's name. | a drawing carries the idea; the voice explains |
