# FACTCHECK — show-tell-ordertrail-pitch

The narration is the author's own pitch, verbatim. Claims about the author's plans are the author's
(EXEMPT: statements of intent). External facts are checked below.

| # | Beat | Claim | Verdict | Source | Fix |
|---|---|---|---|---|---|
| 1 | B06 | Procore is a full construction management platform | PASS | procore.com product description (construction management software) | — |
| 2 | B06 | Odoo has a free purchasing module, but it means adopting a whole ERP | PASS | odoo.com: Purchase app, free in Community edition; part of the Odoo ERP suite | — |
| 3 | B07 | A three-way match checks that the purchase order, the delivery (receipt) and the invoice agree | PASS | standard accounts-payable definition | — |
| 4 | B09/B10 | The dashboard is a mock-up and does not exist yet | PASS | author's script; labelled "mock-up" and "not built yet" on screen | — |
| 5 | B19 | Backtest windows, hits and the miss | EXEMPT | a drawing of the planned method; no numbers are claimed | — |
| 6 | B01–B22 | the author's plans, scope, background and risks | EXEMPT | author's script (statements about their own project) | — |

On-screen labels are 1–3 words taken from the script; the phone message "Where is the rebar order?"
is the script's own Picture note.
| 7 | BAI1–BAI3 | where AI is used (column mapping presented as a possible extension, suggestions confirmed by the author; plain-language alerts citing records; Claude Code helping plan, generate synthetic data and draft tests, reviewed by the author) | EXEMPT | statements of the author's plan; section drafted by Claude at the author's request (2026-10-11), consistent with the pitch's "code calculates, Claude explains" rule | author to confirm wording |
