# FACTCHECK — show-tell-tripmate-pitch

## Executive summary

This file lists every factual claim the TripMate pitch film makes about the outside world, where each
one was checked, and the result. Claims about Smit's own plans are statements of intent and are marked
exempt. The only number in the film that comes from data is the Ahmedabad–Goa route, and it comes from
a saved file.

## Claims

| # | Beat | Claim | Verdict | Source | Checked |
|---|---|---|---|---|---|
| 1 | B07 | Wanderlog has an AI assistant and a budget tracker, but you add places and costs yourself | PASS | wanderlog.com (trip planner and travel-map pages: AI assistant; "one click adds a suggested place" to a list or itinerary; budget feature to "track expenses"); co-founder's blog post describing the assistant as ChatGPT with a map | 2026-10-23, by Claude (web search); 2026-10-24, by Smit: tried it; it did not show the best route or suggest how a day at the destination looks, and he had to select places himself |
| 2 | B07 | Roadtrippers shows where to look for stops, but you pick each one | PASS | Roadtrippers help, "Planning a Trip on Our Website" (measured stops: "we'll show you where to look for a stop along your route"); Roadtrippers forum, "Can I edit hours to drive for each day individually?" | 2026-10-23, by Claude (web search); 2026-10-24, by Smit: tried it; it was not working for Indian cities |
| 3 | B09 | Ahmedabad to Goa is about 1,036 km and 12.7 hours of driving | PASS | `evidence/osrm-ahmedabad-panaji-2026-10-23.json`: OSRM demo server (router.project-osrm.org), OpenStreetMap data, Ahmedabad (72.5714, 23.0225) to Panaji (73.8278, 15.4909); distance 1,035.7 km, duration 12.7 h (no traffic, no breaks); fetched 2026-10-23T20:42Z | 2026-10-23 |
| 4 | B10 | With a five-hour daily limit, that is three driving days | PASS | arithmetic on row 3: 12.7 h ÷ 5 h = 2.54, rounded up to 3 days | 2026-10-23 |
| 5 | B22 | Google's APIs give places, hours and travel times, not flight or hotel prices | PASS | Google Maps Platform pricing pages (Places API, Routes API SKUs); Google ended its QPX Express flight API on April 10, 2018 (Digital Trends; TechTimes; Duffel blog "Google Flights API"); no public Google hotel-price API found | 2026-10-23, by Claude (web search) |
| 6 | B22 | Amadeus closed its free developer APIs in July (2026) | PASS | PhocusWire, "Amadeus to shut down self-service APIs portal for developers" (portal decommissioned July 17, 2026; Enterprise unaffected) | 2026-10-23, by Claude (web search) |
| 7 | B23 | A flight API such as Duffel | PLAN, to confirm | named as an option, not a claim about its terms; **Smit to check Duffel's developer access and pricing before building** | — |
| 8 | B04A, B04B, B04C, B04D | Travel-mode bars, hotel cards, the Goa plan and the day map are drawings of planned features | PASS | labelled "constructed" (B04A) and "example" (B04C) on screen; bars carry no numbers; no hotel or place is named | — |
| 9 | B04C | Goa has beaches and forts, used as example interests | PASS (general knowledge) | Goa's coast and its Portuguese-era forts are widely documented; used only as an example | 2026-10-23 |
| 10 | B10, B12 | The day split and the app screen are mock-ups | PASS | labelled "constructed" and "constructed · mock-up" on screen | — |
| 11 | B24, B25 | Smit knows Python, REST APIs, data pipelines and dashboards, has no public projects yet, and is building TripMate from scratch | EXEMPT (author's own statement, 2026-10-24) | Smit in chat, 2026-10-24: knowledge only, nothing built yet. The earlier co-op and repository claims were removed. | 2026-10-24 |
| 12 | all others | TripMate's features, scope, risks, evaluation plan and reasons | EXEMPT | statements of the author's plan | — |

## Honesty-rule check

- Past tense is used only for: pulling the route (B09, row 3) and what exists today (B27: this pitch,
  the brief, the route sample).
- Every other capability is a description of the plan, framed by "When it's done" (B05) and closed by
  "Everything else is what I will build" (B27).
- No users, employers, metrics, testimonials or results are invented. The 20-trip evaluation is a plan.
- No Claude response is shown in the film.
