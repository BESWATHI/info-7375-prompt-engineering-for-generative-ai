"""
iso_kit.py — the show-tell drawing kit. PASTE this block at the top of a reel's scenes.py;
do not import it (Gate A copies only scenes.py into its sandbox).

Drawn isometric objects in the Claude palette: cardboard boxes (closed, open, taped), dark
MCP blocks with ports, flat skill pages, server stacks with lights, checks, a cursor, pills,
and a WRITING KIT (quill, inkwell, paper, scribble lines, branching outline + the write_lines /
grow_tree animations that make the quill write). A PERSON IS NEVER AN ICON: `professor_bear(ratio, …)`
places a random Professor Bear portrait of the right aspect ratio (PROFESSOR BEAR LAW).
Pacing helpers read the reel's beat_sheet.json so scenes wait for their spoken phrase.

Every rule in ../SKILL.md "DRAWING LAWS" is already obeyed by these primitives; keep it that
way when you add one (label beside, never inside; terracotta never under text; dim greys
with gaps for chart blocks; type floor 32).
"""
from manim import *
import numpy as np
import json as _json, os as _os

# ═════════════════════════════ ISO KIT (show-tell) ═════════════════════════════
STAGE = "#F2F0E9"; INK = "#3D3929"; TERRA = "#D97757"; DIM = "#8B8F96"; GHOST = "#D9D4C7"; CARD = "#FAF9F5"
BOX_TOP, BOX_L, BOX_R = "#F3E9D8", "#DCC9AA", "#C7AE86"          # kraft cardboard: top, left face, right face (deep enough for Gate V contrast)
BOX_IN1, BOX_IN2, BOX_FLOOR = "#CDB894", "#BFA67E", "#B39A72"     # inside walls + floor
DARK_TOP, DARK_L, DARK_R = "#3A3530", "#26221F", "#1E1B18"        # MCP / server blocks
PAGE_TOP, PAGE_L, PAGE_R = "#FFFFFF", "#ECE7DF", "#E2DCD2"         # skill pages
BAR1, BAR2, BAR3 = "#8B8F96", "#B4AFA6", "#D9D4C7"                # chart segments, dim to ghost
SERIF = "EB Garamond"
C30 = 0.8660254
config.background_color = STAGE


def T(s, size=36, color=INK, bold=False):
    return Text(s, font=SERIF, color=color, font_size=size, weight="BOLD" if bold else "NORMAL")


class Iso:
    """Isometric projection: x runs right-up, y runs left-up, z runs up. (ox, oy) is where (0,0,0) lands."""
    def __init__(self, ox=0.0, oy=0.0, s=1.0):
        self.ox, self.oy, self.s = ox, oy, s

    def p(self, x, y, z=0.0):
        return np.array([self.ox + (x - y) * C30 * self.s, self.oy + (x + y) * 0.5 * self.s + z * self.s, 0.0])

    def v(self, dx, dy, dz=0.0):
        return self.p(dx, dy, dz) - self.p(0, 0, 0)

    def quad(self, pts, fill, stroke=INK, sw=4):
        return Polygon(*[self.p(*q) for q in pts], fill_color=fill, fill_opacity=1, stroke_color=stroke, stroke_width=sw)

    def box(self, x0, y0, z0, w, d, h, top=BOX_TOP, left=BOX_L, right=BOX_R, sw=4):
        """Closed box: the two front faces (x = x0 and y = y0) plus the top."""
        x1, y1, z1 = x0 + w, y0 + d, z0 + h
        return VGroup(
            self.quad([(x0, y0, z0), (x0, y1, z0), (x0, y1, z1), (x0, y0, z1)], left, sw=sw),
            self.quad([(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)], right, sw=sw),
            self.quad([(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)], top, sw=sw))

    def open_box(self, x0, y0, z0, w, d, h):
        """(back, front): floor + inner back walls, then the front walls. Put contents between them."""
        x1, y1, z1 = x0 + w, y0 + d, z0 + h
        back = VGroup(
            self.quad([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], BOX_FLOOR),
            self.quad([(x1, y0, z0), (x1, y1, z0), (x1, y1, z1), (x1, y0, z1)], BOX_IN1),
            self.quad([(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)], BOX_IN2))
        front = VGroup(
            self.quad([(x0, y0, z0), (x0, y1, z0), (x0, y1, z1), (x0, y0, z1)], BOX_L),
            self.quad([(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)], BOX_R))
        back.set_z_index(0); front.set_z_index(2)
        return back, front

    def tape(self, x0, y0, z1, w, d, drop=0.35, t=0.22):
        """Terracotta tape across the top (along x) and down the left front face."""
        ym = y0 + d / 2
        return VGroup(
            self.quad([(x0, ym - t, z1), (x0 + w, ym - t, z1), (x0 + w, ym + t, z1), (x0, ym + t, z1)], TERRA, sw=0),
            self.quad([(x0, ym - t, z1), (x0, ym + t, z1), (x0, ym + t, z1 - drop), (x0, ym - t, z1 - drop)], TERRA, sw=0))

    def mcp(self, x0, y0, z0, w=1.3, d=1.3, h=0.7):
        """Dark MCP block with two light ports on its right front face."""
        body = self.box(x0, y0, z0, w, d, h, DARK_TOP, DARK_L, DARK_R)
        ports = VGroup(*[self.box(x0 + w * f, y0 - 0.18, z0 + h * 0.3, w * 0.16, 0.18, h * 0.3, GHOST, BOX_IN1, BOX_IN2, sw=1)
                         for f in (0.22, 0.58)])
        return VGroup(body, ports)

    def page(self, x0, y0, z0, w=1.1, d=1.4):
        """A skill page lying flat: white slab, three ghost text lines, one terracotta dot."""
        slab = self.box(x0, y0, z0, w, d, 0.06, PAGE_TOP, PAGE_L, PAGE_R, sw=1.5)
        zt = z0 + 0.06
        lines = VGroup(*[Line(self.p(x0 + 0.2, y0 + d * f, zt), self.p(x0 + w - 0.2, y0 + d * f, zt), color=GHOST, stroke_width=4)
                         for f in (0.3, 0.5, 0.7)])
        dot = Dot(self.p(x0 + 0.2, y0 + d * 0.86, zt), radius=0.06, color=TERRA)
        return VGroup(slab, lines, dot)

    def server(self, x0, y0, z0, w=1.4, d=1.4, slab=0.42, n=3):
        """A stack of dark server slabs; returns (stack, lights) — lights start ghost, turn terracotta."""
        stack = VGroup(*[self.box(x0, y0, z0 + i * (slab + 0.04), w, d, slab, DARK_TOP, DARK_L, DARK_R) for i in range(n)])
        lights = VGroup(*[Dot(self.p(x0 + 0.25, y0, z0 + i * (slab + 0.04) + slab / 2), radius=0.06, color=GHOST) for i in range(n)])
        return stack, lights


def ease_in(t):
    """Quadratic ease-in (things dropping into a box). Local: Gate A's stub has no ease_in_quad."""
    return t * t


def check(x, y, s=0.2, color=INK, w=7):
    return VGroup(Line([x - s, y, 0], [x - s * 0.3, y - s * 0.75, 0], color=color, stroke_width=w),
                  Line([x - s * 0.3, y - s * 0.75, 0], [x + s * 1.1, y + s * 0.85, 0], color=color, stroke_width=w))


def cursor(x, y, s=0.45):
    return Polygon([x, y, 0], [x, y - s, 0], [x + s * 0.28, y - s * 0.72, 0], [x + s * 0.62, y - s * 0.66, 0],
                   fill_color=INK, fill_opacity=1, stroke_color=CARD, stroke_width=2)


def pill(x, y, w, h=0.62, fill="#FFFFFF"):
    return RoundedRectangle(width=w, height=h, corner_radius=h / 2, fill_color=fill, fill_opacity=1, stroke_width=0).move_to([x, y, 0])


# ═════════════════════════════ WRITING KIT (quill, ink, paper, scribble) ═════════════════════════════
# Added 2026-10-07 from Bear's two reference drawings: a quill drawing a branching outline on a
# scroll, and three scattered pages of scribbled handwriting with a quill. Use when a beat is
# about writing, drafting, authorship, notes, a manuscript, a log, a letter, a signature.
# Terracotta here is only the ink drop and the outline's nodes (dots) — never the lines.


def quill(x, y, s=1.0, angle=0.0, color=INK, fill=BOX_TOP):
    """A drawn quill with its NIB at (x, y); the feather points up-right. `g.nib` is the nib point.
    Kraft-filled feather, ink outline, a shaft line and one barb. Rotate with `angle` (radians)."""
    o = np.array([x, y, 0.0])
    def P(u, v):  # icon units (0..1) → scene, nib at origin, tip at (1, 1.1)·s
        return o + np.array([u * s, v * s, 0.0])
    body = VMobject(fill_color=fill, fill_opacity=1, stroke_color=color, stroke_width=4)
    body.set_points_smoothly([P(0.00, 0.00), P(0.12, 0.62), P(0.55, 1.02), P(1.00, 1.10),
                              P(0.95, 0.68), P(0.62, 0.22), P(0.00, 0.00)])
    shaft = Line(P(0.02, 0.02), P(0.98, 1.06), color=color, stroke_width=3)
    barb = Line(P(0.46, 0.50), P(0.40, 0.72), color=color, stroke_width=2.5)
    g = VGroup(body, shaft, barb)
    if angle:
        g.rotate(angle, about_point=o)
    g.nib = o.copy()
    return g


def inkwell(iso, x0=0.0, y0=0.0, z0=0.0, s=0.7):
    """A dark ink bottle (iso box + narrow neck) with one terracotta ink dot on the lid."""
    body = iso.box(x0, y0, z0, s, s, s * 0.9, DARK_TOP, DARK_L, DARK_R)
    neck = iso.box(x0 + s * 0.3, y0 + s * 0.3, z0 + s * 0.9, s * 0.4, s * 0.4, s * 0.25, DARK_TOP, DARK_L, DARK_R)
    drop = Dot(iso.p(x0 + s * 0.5, y0 + s * 0.5, z0 + s * 1.15), radius=0.07, color=TERRA)
    return VGroup(body, neck, drop)


def paper(x, y, w=2.4, h=3.0, tilt=0.0, fill=PAGE_TOP):
    """A flat 2-D sheet (the scattered-pages drawing): white page, ink outline, kraft drop shadow.
    `tilt` in radians. Returns a VGroup; `.sheet` is the page rectangle for placing lines on it."""
    shadow = Rectangle(width=w, height=h, fill_color=BOX_L, fill_opacity=1, stroke_width=0).move_to([x + 0.12, y - 0.12, 0])
    sheet = Rectangle(width=w, height=h, fill_color=fill, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    g = VGroup(shadow, sheet)
    if tilt:
        g.rotate(tilt, about_point=[x, y, 0])
    g.sheet = sheet
    g.cx, g.cy, g.w, g.h, g.tilt = float(x), float(y), float(w), float(h), float(tilt)   # read these; never ask the stub for vertices
    return g


def scribble(x, y, w, amp=0.07, waves=None, color=INK, sw=4):
    """One wavy handwriting line from (x, y) rightwards for `w` units. Reads as script, never as type."""
    n = waves or max(3, int(round(w * 3)))
    pts = []
    for i in range(n * 4 + 1):
        t = i / (n * 4)
        pts.append([x + w * t, y + amp * np.sin(t * n * 2 * np.pi) * (0.6 + 0.4 * np.cos(t * 5.3)), 0])
    m = VMobject(stroke_color=color, stroke_width=sw)
    m.set_points_smoothly(pts)
    return m


def scribble_block(x, y, w, n=3, gap=0.34, last=0.62, color=INK, sw=4):
    """`n` scribble lines stacked downward from (x, y); the last one is `last`× as long (a paragraph end)."""
    return VGroup(*[scribble(x, y - i * gap, w * (last if i == n - 1 else 1.0), color=color, sw=sw) for i in range(n)])


def scribbles_on(page, n=3, inset=0.3, gap=0.34, color=INK, sw=4):
    """Scribble lines laid on a `paper()` group, following its tilt (uses the page's stored geometry)."""
    w = page.w - 2 * inset
    g = scribble_block(page.cx - w / 2, page.cy + page.h / 2 - inset - 0.1, w, n=n, gap=gap, color=color, sw=sw)
    if abs(page.tilt) > 1e-3:
        g.rotate(page.tilt, about_point=[page.cx, page.cy, 0])
    return g


def outline_tree(x, y, h=1.6, levels=2, spread=0.55, color=INK, node=TERRA):
    """A branching outline (the scroll drawing): a trunk rising from (x, y), forking `levels` times,
    a terracotta dot at every tip. Returns VGroup(lines, dots) — draw lines first, dots last."""
    lines, dots = VGroup(), VGroup()
    def grow(px, py, length, lvl, dx):
        qx, qy = px + dx, py + length
        lines.add(Line([px, py, 0], [qx, qy, 0], color=color, stroke_width=4))
        if lvl == 0:
            dots.add(Dot([qx, qy, 0], radius=0.075, color=node))
            return
        for d in (-spread, spread):
            grow(qx, qy, length * 0.62, lvl - 1, d * (0.75 ** (levels - lvl)))
    grow(x, y, h * 0.42, levels, 0.0)
    g = VGroup(lines, dots)
    g.lines, g.dots = lines, dots
    return g


def write_lines(self, q, lines, speed=1.6, hop=0.22, dip=0.06):
    """Animate the quill `q` WRITING each line in `lines`: the nib hops to the line's start, then the
    line draws while the nib rides its tip (the writing motion). `speed` is scene units per second.
    Call between `until()` phrases so each line lands on its words. Works with the midpoint guard."""
    for ln in lines:
        start = np.array(ln.get_start(), dtype=float)
        self.play(q.animate.shift(start - q.nib), run_time=hop, rate_func=smooth)
        q.nib = start.copy()
        off = np.array(q.get_center(), dtype=float) - q.nib
        def ride(m, a, ln=ln, off=off):
            m.move_to(np.array(ln.point_from_proportion(min(1.0, a)), dtype=float) + off)
        try:
            length = float(ln.get_arc_length())
        except Exception:          # Gate A's stub has no arc length; any positive number keeps the check moving
            length = 2.0
        rt = max(0.35, length / speed)
        self.play(Create(ln), UpdateFromAlphaFunc(q, ride), run_time=rt, rate_func=linear)
        q.nib = np.array(ln.get_end(), dtype=float)
        # the small lift between lines keeps the quill from fusing with the ink at GATE T's midpoint
        q.shift([0, dip, 0]); q.nib = q.nib + np.array([0, dip, 0])


def grow_tree(self, q, tree, per=0.45):
    """Animate the quill drawing an `outline_tree`: each segment draws as the nib rides it; dots land last."""
    for ln in tree.lines:
        start = np.array(ln.get_start(), dtype=float)
        self.play(q.animate.shift(start - q.nib), run_time=0.18, rate_func=smooth)
        q.nib = start.copy()
        off = np.array(q.get_center(), dtype=float) - q.nib
        def ride(m, a, ln=ln, off=off):
            m.move_to(np.array(ln.point_from_proportion(min(1.0, a)), dtype=float) + off)
        self.play(Create(ln), UpdateFromAlphaFunc(q, ride), run_time=per, rate_func=linear)
        q.nib = np.array(ln.get_end(), dtype=float)
    self.play(LaggedStart(*[GrowFromCenter(d) for d in tree.dots], lag_ratio=0.15), run_time=0.6)


# ═════════════════════════════ PROFESSOR BEAR (a person is never an icon) ═════════════════════════════
# PROFESSOR BEAR LAW (Bear, 2026-10-07): when a beat needs an icon of a person, or Professor Bear himself,
# do not draw a person token and do not pull a person icon. Show one of the Professor Bear portraits in
# brutalist.art/professor-bear/, chosen at random among those of the right aspect ratio (1x1 · 2x3 · 16x9).
# `./art bear <ratio> --seed <beat>` picks the same way from the shell.
def _pb_dir():
    env = _os.environ.get("ART_HOME")
    cands = [env and _os.path.join(env, "professor-bear")]
    here = _os.path.dirname(_os.path.abspath(__file__))
    for _ in range(8):
        cands.append(_os.path.join(here, "brutalist.art", "professor-bear"))
        cands.append(_os.path.join(here, "professor-bear"))
        here = _os.path.dirname(here)
    cands.append("/Users/bear/Documents/CoWork/bear-textbooks/books/brutalist.art/professor-bear")
    for c in cands:
        if c and _os.path.isdir(c):
            return c
    return cands[-1]


_PB_RATIOS = {"1x1": (1.0, 229), "2x3": (2 / 3, 28), "16x9": (16 / 9, 13)}


def _pb_circle(path):
    """A circular cut (alpha outside the circle), cached beside the set in _crops/. Cropping is fine (Bear, 2026-10-07)."""
    from PIL import Image as _Im, ImageDraw as _Dr
    out_dir = _os.path.join(_os.path.dirname(path), "_crops"); _os.makedirs(out_dir, exist_ok=True)
    out = _os.path.join(out_dir, _os.path.splitext(_os.path.basename(path))[0] + "-circle.png")
    if not _os.path.exists(out):
        im = _Im.open(path).convert("RGBA"); w, h = im.size; s = min(w, h); top = max(0, (h - s) // 3)
        im = im.crop(((w - s) // 2, top, (w - s) // 2 + s, top + s))
        mask = _Im.new("L", (s, s), 0); _Dr.Draw(mask).ellipse((0, 0, s - 1, s - 1), fill=255)
        im.putalpha(mask); im.save(out)
    return out


def professor_bear(ratio="2x3", height=3.0, seed=None, x=0.0, y=0.0, frame=True, shape="rect"):
    """A Professor Bear portrait (random within `ratio`; `seed` = the beat id for a stable pick across re-renders).
    Returns a Group: kraft drop shadow, the photo, an ink frame. Place with `x, y`; size with `height`.
    `shape="circle"` gives a round cut (use a 1x1 portrait). Cropping is fine: circle, rounded square, tight head shot."""
    import random as _random
    ar, n = _PB_RATIOS[ratio]
    k = _random.Random(str(seed) if seed is not None else None).randint(1, n)
    path = _os.path.join(_pb_dir(), f"professor-bear-{ratio}-{k:02d}.png")
    circle = shape == "circle"
    if circle:
        ar = 1.0
    w = height * ar
    if circle:
        shadow = Circle(radius=height / 2, fill_color=BOX_L, fill_opacity=1, stroke_width=0).move_to([x + 0.12, y - 0.12, 0])
        border = Circle(radius=height / 2, stroke_color=INK, stroke_width=4, fill_opacity=0).move_to([x, y, 0])
    else:
        shadow = Rectangle(width=w, height=height, fill_color=BOX_L, fill_opacity=1, stroke_width=0).move_to([x + 0.12, y - 0.12, 0])
        border = Rectangle(width=w, height=height, stroke_color=INK, stroke_width=4, fill_opacity=0).move_to([x, y, 0])
    try:
        img = ImageMobject(_pb_circle(path) if circle else path)
        img.height = height
        img.move_to([x, y, 0])
    except Exception:
        img = Rectangle(width=w, height=height, fill_color=BAR2, fill_opacity=1, stroke_width=0).move_to([x, y, 0])
    g = Group(shadow, img, border) if frame else Group(img)
    g.path = path
    return g


# ═════════════════════════════ pacing (narration is the clock) ═════════════════════════════
try:
    _SHEET = _json.load(open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "beat_sheet.json")))
    _TARGET = {b["beat_id"]: float(b.get("actual_duration_s") or b.get("estimated_duration_s") or 0) for b in _SHEET["beats"]}
    _NARR = {b["beat_id"]: b["narration_text"] for b in _SHEET["beats"]}
except Exception:
    _TARGET, _NARR = {}, {}


def _elapsed(self):
    rt = getattr(getattr(self, "renderer", None), "time", None)
    return float(rt) if isinstance(rt, (int, float)) else 0.0


def until(self, phrase, lead=0.25):
    """Wait until `phrase` is spoken (its character share of the narration × the measured audio)."""
    bid = type(self).__name__.split("_")[0]
    n, target = _NARR.get(bid, ""), _TARGET.get(bid, 0)
    if not n or not target or phrase not in n:
        return
    gap = target * n.index(phrase) / len(n) - lead - _elapsed(self)
    if gap > 0.05:
        self.wait(gap)


def finish(self):
    target = _TARGET.get(type(self).__name__.split("_")[0], 0)
    self.wait(max(0.3, target - _elapsed(self)) if target else 2.0)


# ═════════════════════════════ TripMate pitch — reel-local helpers ═════════════════════════════
_kit_scribble = scribble


def scribble(x, y, w, amp=0.1, waves=None, color=INK, sw=4):
    """Taller handwriting waves than the kit default: at amp 0.07 a line measures 40 px at 4K and
    GATE T reads it as sub-floor text (floor 41 px)."""
    return _kit_scribble(x, y, w, amp=amp, waves=waves, color=color, sw=sw)

KRAFT_EDGE = "#9C8462"   # connectors: deep kraft, never ink (ink cables fuse objects into one 'text' blob)
MARGIN = 0.25            # keep every animation off the clip midpoint (GATE T / Gate V sample there)


def _bid(self):
    return type(self).__name__.split("_")[0]


def G(self, *anims, rt=0.6, **kw):
    """Guarded play: never let an animation span the clip midpoint."""
    tgt = _TARGET.get(_bid(self), 0)
    t = _elapsed(self)
    if tgt:
        mid = tgt / 2
        if t < mid + MARGIN and t + rt > mid - MARGIN:
            self.wait(mid + MARGIN - t)
    self.play(*anims, run_time=rt, **kw)


def L(s, x, y, size=34, color=INK):
    return T(s, size, color).move_to([x, y, 0])


def L38(s, x, y, size=38, color=INK):
    return T(s, size, color).move_to([x, y, 0])


def crate(iso, x, y, w=0.9, d=0.9, h=0.7):
    return iso.box(x, y, 0, w, d, h)


def phone(x, y, h=2.6):
    w = h * 0.52
    body = RoundedRectangle(width=w, height=h, corner_radius=0.18, fill_color=DARK_L, fill_opacity=1,
                            stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    screen = RoundedRectangle(width=w - 0.22, height=h - 0.5, corner_radius=0.08, fill_color=CARD,
                              fill_opacity=1, stroke_width=0).move_to([x, y + 0.05, 0])
    return VGroup(body, screen)


def bubble(s, x, y, size=32):
    t = T(s, size)
    b = RoundedRectangle(width=t.width + 0.5, height=t.height + 0.4, corner_radius=0.2,
                         fill_color=GHOST, fill_opacity=1, stroke_width=0).move_to([x, y, 0])
    return VGroup(b, t.move_to(b))


def hard_hat(x, y, r=0.32):
    dome = Sector(radius=r, angle=PI, fill_color=BOX_TOP, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y + r * 0.42, 0])
    brim = Line([x - r * 1.35, y, 0], [x + r * 1.35, y, 0], color=INK, stroke_width=6)
    return VGroup(dome, brim)


def window(x, y, w=4.0, h=2.6):
    """A pale app window carried by a grey title band and dark-ish content blocks (Gate V contrast)."""
    frame = Rectangle(width=w, height=h, fill_color=CARD, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    band = Rectangle(width=w, height=0.32, fill_color=BAR1, fill_opacity=1, stroke_width=0).move_to([x, y + h / 2 - 0.16, 0])
    return VGroup(frame, band)


def rows(x0, y0, widths, gap=0.36, h=0.16, color=BAR1):
    return VGroup(*[Rectangle(width=wd, height=h, fill_color=color, fill_opacity=1, stroke_width=0)
                    .move_to([x0 + wd / 2, y0 - i * gap, 0]) for i, wd in enumerate(widths)])


def sheet(x, y, w=1.3, h=1.7, n=3):
    p = paper(x, y, w, h)
    return VGroup(p, scribbles_on(p, n=n, inset=0.22, gap=0.3))


def clock(x, y, r=0.32):
    c = Circle(radius=r, fill_color=CARD, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    h1 = Line([x, y, 0], [x, y + r * 0.65, 0], color=INK, stroke_width=4)
    h2 = Line([x, y, 0], [x + r * 0.5, y, 0], color=INK, stroke_width=4)
    return VGroup(c, h1, h2)


def cross(x, y, s=0.22, color=INK, w=7):
    return VGroup(Line([x - s, y - s, 0], [x + s, y + s, 0], color=color, stroke_width=w),
                  Line([x - s, y + s, 0], [x + s, y - s, 0], color=color, stroke_width=w))


def arrow(a, b, color=KRAFT_EDGE, w=6):
    return Arrow(a, b, color=color, stroke_width=w, buff=0.1, max_tip_length_to_length_ratio=0.18)


def plinth(ox, oy, x0, y0, w, d, pad=0.15, h=0.22):
    """Dark slab under a pale kraft object (show-tell: 'a pale kraft block on its own fails Gate V')."""
    return Iso(ox, oy, 1.0).box(x0 - pad, y0 - pad, -h, w + 2 * pad, d + 2 * pad, h, DARK_TOP, DARK_L, DARK_R)


def ground(y=-2.6):
    return Line([-6.0, y, 0], [6.0, y, 0], color=GHOST, stroke_width=4)


# ═════════════════════════════ TripMate drawing helpers ═════════════════════════════
def road(a, b, w=16):
    """A grey road from a to b with a pale dashed centre line."""
    base = Line(a, b, color=BAR1, stroke_width=w)
    dash = DashedLine(a, b, color=CARD, stroke_width=3, dash_length=0.18, dashed_ratio=0.5)
    return VGroup(base, dash)


def pin(x, y, s=0.32, color=INK, dot=CARD):
    """A map pin whose point sits on (x, y)."""
    head = Circle(radius=s, fill_color=color, fill_opacity=1, stroke_width=0).move_to([x, y + s * 1.55, 0])
    tip = Polygon([x, y, 0], [x - s * 0.8, y + s * 1.2, 0], [x + s * 0.8, y + s * 1.2, 0],
                  fill_color=color, fill_opacity=1, stroke_width=0)
    hole = Dot([x, y + s * 1.55, 0], radius=s * 0.38, color=dot)
    return VGroup(tip, head, hole)


def bed(x, y, s=1.0):
    """A small bed seen from the side: dark headboard, kraft mattress, white pillow."""
    head = Rectangle(width=0.16 * s, height=0.7 * s, fill_color=DARK_L, fill_opacity=1, stroke_width=0).move_to([x - 0.52 * s, y + 0.22 * s, 0])
    frame = Rectangle(width=1.1 * s, height=0.28 * s, fill_color=BOX_R, fill_opacity=1, stroke_color=INK, stroke_width=3).move_to([x, y, 0])
    pillow = RoundedRectangle(width=0.32 * s, height=0.16 * s, corner_radius=0.06, fill_color=CARD, fill_opacity=1,
                              stroke_color=INK, stroke_width=2).move_to([x - 0.25 * s, y + 0.22 * s, 0])
    legs = VGroup(*[Line([x + dx * s, y - 0.14 * s, 0], [x + dx * s, y - 0.3 * s, 0], color=INK, stroke_width=4) for dx in (-0.48, 0.48)])
    return VGroup(head, frame, pillow, legs)


def car(x, y, s=1.0):
    """A side-on car: kraft body, darker cabin with a pale window, two dark wheels."""
    body = RoundedRectangle(width=1.7 * s, height=0.42 * s, corner_radius=0.14 * s, fill_color=BOX_R, fill_opacity=1,
                            stroke_color=INK, stroke_width=4).move_to([x, y + 0.36 * s, 0])
    cabin = Polygon([x - 0.5 * s, y + 0.57 * s, 0], [x - 0.28 * s, y + 0.95 * s, 0], [x + 0.36 * s, y + 0.95 * s, 0],
                    [x + 0.56 * s, y + 0.57 * s, 0], fill_color=BOX_L, fill_opacity=1, stroke_color=INK, stroke_width=4)
    win = Polygon([x - 0.34 * s, y + 0.62 * s, 0], [x - 0.2 * s, y + 0.86 * s, 0], [x + 0.3 * s, y + 0.86 * s, 0],
                  [x + 0.42 * s, y + 0.62 * s, 0], fill_color=CARD, fill_opacity=1, stroke_width=0)
    wheels = VGroup(*[Circle(radius=0.2 * s, fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=3)
                      .move_to([x + dx * s, y + 0.16 * s, 0]) for dx in (-0.5, 0.5)])
    return VGroup(cabin, win, body, wheels)


def calculator(x, y, s=1.0):
    case = RoundedRectangle(width=1.1 * s, height=1.5 * s, corner_radius=0.1, fill_color=DARK_L, fill_opacity=1,
                            stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    screen = Rectangle(width=0.8 * s, height=0.3 * s, fill_color=CARD, fill_opacity=1, stroke_width=0).move_to([x, y + 0.45 * s, 0])
    keys = VGroup(*[Square(side_length=0.18 * s, fill_color=GHOST, fill_opacity=1, stroke_width=0)
                    .move_to([x + (c - 1) * 0.28 * s, y - 0.05 * s - r * 0.28 * s, 0]) for r in range(3) for c in range(3)])
    return VGroup(case, screen, keys)


def folded_map(x, y, s=1.0):
    """A three-panel folded map on a dark plinth, with a route line across it."""
    w, h = 0.55 * s, 1.3 * s
    panels = VGroup()
    for i, (fill, dy) in enumerate(((BOX_L, 0.0), (BOX_TOP, 0.12 * s), (BOX_L, 0.0))):
        cx = x + (i - 1) * w
        panels.add(Polygon([cx - w / 2, y - h / 2 + (0.12 * s if i == 1 else 0), 0], [cx + w / 2, y - h / 2 + (0 if i == 1 else 0.12 * s), 0],
                           [cx + w / 2, y + h / 2 + (0 if i == 1 else 0.12 * s), 0], [cx - w / 2, y + h / 2 + (0.12 * s if i == 1 else 0), 0],
                           fill_color=fill, fill_opacity=1, stroke_color=INK, stroke_width=3))
    route = VMobject(stroke_color=INK, stroke_width=5)
    route.set_points_smoothly([[x - 1.4 * w, y - 0.3 * s, 0], [x - 0.4 * w, y + 0.25 * s, 0], [x + 0.5 * w, y - 0.15 * s, 0], [x + 1.4 * w, y + 0.35 * s, 0]])
    slab = Rectangle(width=3 * w + 0.4, height=0.2, fill_color=DARK_L, fill_opacity=1, stroke_width=0).move_to([x, y - h / 2 - 0.2, 0])
    return VGroup(slab, panels, route)


def suitcase(x, y, s=1.0):
    case = RoundedRectangle(width=1.5 * s, height=1.1 * s, corner_radius=0.12, fill_color=DARK_L, fill_opacity=1,
                            stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    handle = RoundedRectangle(width=0.5 * s, height=0.3 * s, corner_radius=0.08, stroke_color=INK, stroke_width=6,
                              fill_opacity=0).move_to([x, y + 0.65 * s, 0])
    straps = VGroup(*[Line([x + dx * s, y - 0.55 * s, 0], [x + dx * s, y + 0.55 * s, 0], color=BOX_R, stroke_width=6) for dx in (-0.4, 0.4)])
    return VGroup(handle, case, straps)


def car_key(x, y, s=1.0):
    fob = RoundedRectangle(width=0.36 * s, height=0.6 * s, corner_radius=0.12, fill_color=DARK_L, fill_opacity=1,
                           stroke_color=INK, stroke_width=3).move_to([x, y, 0])
    btn = Dot([x, y + 0.1 * s, 0], radius=0.07 * s, color=GHOST)
    blade = Rectangle(width=0.1 * s, height=0.45 * s, fill_color=BAR1, fill_opacity=1, stroke_color=INK, stroke_width=2).move_to([x, y - 0.52 * s, 0])
    return VGroup(blade, fob, btn)


def laptop(x, y, s=1.0):
    screen = RoundedRectangle(width=2.0 * s, height=1.3 * s, corner_radius=0.08, fill_color=DARK_L, fill_opacity=1,
                              stroke_color=INK, stroke_width=4).move_to([x, y + 0.75 * s, 0])
    inner = Rectangle(width=1.7 * s, height=1.0 * s, fill_color=CARD, fill_opacity=1, stroke_width=0).move_to([x, y + 0.75 * s, 0])
    base = Polygon([x - 1.15 * s, y, 0], [x + 1.15 * s, y, 0], [x + 1.4 * s, y - 0.28 * s, 0], [x - 1.4 * s, y - 0.28 * s, 0],
                   fill_color=BOX_R, fill_opacity=1, stroke_color=INK, stroke_width=4)
    return VGroup(screen, inner, base)


def tag(s, x, y, size=34, fill=CARD):
    t = T(s, size)
    b = RoundedRectangle(width=t.width + 0.5, height=t.height + 0.36, corner_radius=0.16,
                         fill_color=fill, fill_opacity=1, stroke_color=INK, stroke_width=3).move_to([x, y, 0])
    return VGroup(b, t.move_to(b))


def block(x, y, w=1.3, h=0.55, fill=BAR1, ghost=False):
    if ghost:
        return Rectangle(width=w, height=h, stroke_color=DIM, stroke_width=3, fill_opacity=0).move_to([x, y, 0])
    return Rectangle(width=w, height=h, fill_color=fill, fill_opacity=1, stroke_color=INK, stroke_width=3).move_to([x, y, 0])


def card(x, y, w=0.8, h=0.55):
    return RoundedRectangle(width=w, height=h, corner_radius=0.06, fill_color=CARD, fill_opacity=1,
                            stroke_color=INK, stroke_width=3).move_to([x, y, 0])


def ring(x, y, r=0.7):
    base = Circle(radius=r, stroke_color=GHOST, stroke_width=10).move_to([x, y, 0])
    sweep = Arc(radius=r, start_angle=PI / 2, angle=-TAU, color=INK, stroke_width=10).move_to([x, y, 0])
    return base, sweep


def binder(x, y, w=1.2, h=1.5):
    cover = Rectangle(width=w, height=h, fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    spine = Rectangle(width=0.18, height=h, fill_color=BOX_R, fill_opacity=1, stroke_width=0).move_to([x - w / 2 + 0.09, y, 0])
    label = Rectangle(width=w * 0.5, height=0.22, fill_color=CARD, fill_opacity=1, stroke_width=0).move_to([x + 0.08, y + 0.3, 0])
    return VGroup(cover, spine, label)


def repo_crate(x, y, s=1.0):
    iso = Iso(x, y, s)
    return VGroup(plinth(x, y, -0.6, -0.6, 1.2, 1.2), iso.box(-0.6, -0.6, 0, 1.2, 1.2, 0.8))


ROAD_Y = -1.2
DAY_X = (-5.4, -1.8, 1.8, 5.4)   # road from the first to the last x, split at the middle two


def day_road(y=ROAD_Y):
    return road([DAY_X[0], y, 0], [DAY_X[3], y, 0])


# ═════════════════════════════ Q1 — what is it ═════════════════════════════
class B01_Juggle(Scene):
    def construct(self):
        xs = (-4.8, -1.6, 1.6, 4.8)
        objs = [bed(xs[0], 1.0, 1.4), folded_map(xs[1], 1.2, 0.9), sheet(xs[2], 1.2, 1.3, 1.6, 3), calculator(xs[3], 1.2, 1.0)]
        names = ["hotels", "maps", "blogs", "budget"]
        for obj, n, x, cue in zip(objs, names, xs, ["hotel sites", "maps", "blogs", "a calculator"]):
            until(self, cue)
            G(self, FadeIn(obj, shift=UP * 0.3), FadeIn(L(n, x, -0.35)), rt=0.5)
        until(self, "still guessing")
        r = road([-5.0, -2.3, 0], [4.0, -2.3, 0])
        q = VGroup(pin(4.6, -2.35, 0.34, INK), L("?", 5.5, -1.55, 54))
        G(self, Create(r), FadeIn(q, shift=DOWN * 0.3), rt=0.8)
        finish(self)


class B02_Name(Scene):
    def construct(self):
        r = road([-6.0, -1.6, 0], [6.0, -1.6, 0])
        self.add(r)
        name = T("TripMate", 120).move_to([0, 1.3, 0])
        c = car(-4.6, -1.6, 1.1)
        G(self, FadeIn(name, shift=UP * 0.2), rt=0.6)
        until(self, "TripMate")
        G(self, FadeIn(c), rt=0.5)
        until(self, "what you do each day", lead=1.4)
        trail = Line([-4.6, -2.25, 0], [4.0, -2.25, 0], color=TERRA, stroke_width=6)
        G(self, c.animate.shift(RIGHT * 8.6), Create(trail), rt=1.6, rate_func=smooth)
        G(self, FadeIn(pin(5.4, -1.45, 0.3, TERRA), shift=DOWN * 0.2), rt=0.4)
        finish(self)


class B03_Inputs(Scene):
    def construct(self):
        frame = RoundedRectangle(width=9.6, height=4.6, corner_radius=0.2, fill_color=CARD, fill_opacity=1,
                                 stroke_color=INK, stroke_width=4).move_to([0, 0, 0])
        band = Rectangle(width=9.6, height=0.36, fill_color=BAR1, fill_opacity=1, stroke_width=0).move_to([0, 2.12, 0])
        self.add(frame, band)
        spots = [(-2.6, 1.0), (2.6, 1.0), (-2.6, -0.3), (2.6, -0.3), (-2.6, -1.6), (2.6, -1.6)]
        names = ["start", "destination", "dates", "travelers", "budget", "interests"]
        cues = ["where you start", "where you're going", "dates", "travelers", "budget", "interests"]
        for (x, y), n, cue in zip(spots, names, cues):
            until(self, cue)
            G(self, FadeIn(tag(n, x, y, 38), shift=DOWN * 0.2), rt=0.35)
        finish(self)


class B04_Split(Scene):
    def construct(self):
        self.add(day_road())
        G(self, FadeIn(L("road trip", 0.0, 2.6, 40)), rt=0.4)
        until(self, "splits the road trip")
        ticks = VGroup(*[Line([x, ROAD_Y - 0.35, 0], [x, ROAD_Y + 0.35, 0], color=INK, stroke_width=6) for x in DAY_X[1:3]])
        days = VGroup(*[L(f"Day {i + 1}", (DAY_X[i] + DAY_X[i + 1]) / 2, ROAD_Y - 0.8) for i in range(3)])
        G(self, Create(ticks), FadeIn(days), rt=0.6)
        until(self, "picks where")
        beds = VGroup(*[VGroup(pin(x, ROAD_Y + 0.15, 0.3, TERRA), bed(x, ROAD_Y + 1.55, 0.8)) for x in DAY_X[1:3]])
        G(self, LaggedStart(*[FadeIn(b, shift=DOWN * 0.3) for b in beds], lag_ratio=0.3), rt=0.8)
        until(self, "adds rest breaks")
        dots = VGroup(*[Dot([x, ROAD_Y, 0], radius=0.13, color=INK) for x in (-4.3, -3.0, -0.6, 0.6, 3.0, 4.3)])
        G(self, LaggedStart(*[GrowFromCenter(d) for d in dots], lag_ratio=0.12), FadeIn(L("breaks", 0.0, ROAD_Y + 0.7)), rt=0.8)
        finish(self)



# ═════════════════════════════ new beats: travel mode, hotels, places ═════════════════════════════
def bus(x, y, s=1.0):
    body = RoundedRectangle(width=1.8 * s, height=0.8 * s, corner_radius=0.12, fill_color=BAR1, fill_opacity=1,
                            stroke_color=INK, stroke_width=4).move_to([x, y + 0.5 * s, 0])
    wins = VGroup(*[Rectangle(width=0.3 * s, height=0.25 * s, fill_color=CARD, fill_opacity=1, stroke_width=0)
                    .move_to([x + (i - 1.5) * 0.4 * s, y + 0.62 * s, 0]) for i in range(4)])
    wheels = VGroup(*[Circle(radius=0.16 * s, fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=3)
                      .move_to([x + dx * s, y + 0.1 * s, 0]) for dx in (-0.55, 0.55)])
    return VGroup(body, wins, wheels)


def train(x, y, s=1.0):
    cars = VGroup()
    for i, dx in enumerate((-0.5, 0.5)):
        cars.add(RoundedRectangle(width=0.9 * s, height=0.7 * s, corner_radius=0.18 if i == 0 else 0.06,
                                  fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x + dx * s, y + 0.45 * s, 0]))
        cars.add(Rectangle(width=0.5 * s, height=0.22 * s, fill_color=CARD, fill_opacity=1, stroke_width=0).move_to([x + dx * s, y + 0.55 * s, 0]))
    rail = Line([x - 1.0 * s, y, 0], [x + 1.0 * s, y, 0], color=INK, stroke_width=5)
    return VGroup(rail, cars)


def plane(x, y, s=1.0):
    body = RoundedRectangle(width=1.8 * s, height=0.3 * s, corner_radius=0.15 * s, fill_color=BAR1, fill_opacity=1,
                            stroke_color=INK, stroke_width=3).move_to([x, y + 0.5 * s, 0])
    wing = Polygon([x - 0.1 * s, y + 0.5 * s, 0], [x + 0.35 * s, y + 0.5 * s, 0], [x - 0.25 * s, y - 0.05 * s, 0], [x - 0.5 * s, y - 0.05 * s, 0],
                   fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=3)
    tail = Polygon([x - 0.85 * s, y + 0.55 * s, 0], [x - 0.6 * s, y + 0.55 * s, 0], [x - 0.85 * s, y + 0.95 * s, 0],
                   fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=3)
    return VGroup(wing, body, tail)


def hotel(x, y, s=1.0):
    bld = Rectangle(width=1.2 * s, height=1.6 * s, fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    wins = VGroup(*[Square(side_length=0.2 * s, fill_color=GHOST, fill_opacity=1, stroke_width=0)
                    .move_to([x + (c - 1) * 0.35 * s, y + 0.45 * s - r * 0.38 * s, 0]) for r in range(3) for c in range(3)])
    door = Rectangle(width=0.3 * s, height=0.4 * s, fill_color=BOX_R, fill_opacity=1, stroke_width=0).move_to([x, y - 0.6 * s, 0])
    return VGroup(bld, wins, door)


def wave(x, y, w=1.2):
    return VGroup(*[_kit_scribble(x - w / 2, y - i * 0.3, w, amp=0.12, waves=3, color=INK, sw=6) for i in range(2)])


def fort(x, y, s=1.0):
    wall = Rectangle(width=1.3 * s, height=0.8 * s, fill_color=BAR1, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    merlons = VGroup(*[Rectangle(width=0.22 * s, height=0.22 * s, fill_color=BAR1, fill_opacity=1, stroke_color=INK, stroke_width=3)
                       .move_to([x + (i - 1.5) * 0.36 * s, y + 0.51 * s, 0]) for i in range(4)])
    gate = Rectangle(width=0.3 * s, height=0.42 * s, fill_color=DARK_L, fill_opacity=1, stroke_width=0).move_to([x, y - 0.19 * s, 0])
    return VGroup(wall, merlons, gate)


def plate(x, y, r=0.55):
    outer = Circle(radius=r, fill_color=CARD, fill_opacity=1, stroke_color=INK, stroke_width=4).move_to([x, y, 0])
    inner = Circle(radius=r * 0.6, fill_color=BOX_R, fill_opacity=1, stroke_color=INK, stroke_width=3).move_to([x, y, 0])
    return VGroup(outer, inner)


class B04A_Modes(Scene):
    def construct(self):
        xs = (-3.7, -1.1, 1.5, 4.1)
        makers = [lambda x: car(x, 0.3, 1.0), lambda x: bus(x, 0.3, 1.0), lambda x: train(x, 0.3, 1.0), lambda x: plane(x, 0.3, 1.0)]
        costs, times = (0.9, 0.6, 0.5, 1.6), (1.3, 1.6, 1.4, 0.4)
        for i, (mk, n, cue) in enumerate(zip(makers, ["car", "bus", "train", "plane"], ["driving", "buses", "trains", "flights"])):
            until(self, cue)
            x = xs[i]
            bars = VGroup(Rectangle(width=costs[i], height=0.2, fill_color=INK, fill_opacity=1, stroke_width=0).move_to([x - 0.8 + costs[i] / 2, -0.9, 0]),
                          Rectangle(width=times[i], height=0.2, fill_color=BAR1, fill_opacity=1, stroke_width=0).move_to([x - 0.8 + times[i] / 2, -1.3, 0]))
            G(self, FadeIn(mk(x), shift=UP * 0.2), FadeIn(L(n, x, 1.75)), FadeIn(bars), rt=0.35)
        G(self, FadeIn(L("cost", -5.4, -0.9, 32)), FadeIn(L("time", -5.4, -1.3, 32)), rt=0.3)
        until(self, "best fit", lead=0.8)
        G(self, Create(check(xs[2] + 0.05, 2.6, 0.28)), FadeIn(L("fits budget", -0.2, 2.7)), FadeIn(L("constructed", 0.0, -2.8, 32, DIM)), rt=0.5)
        finish(self)


class B04B_Hotels(Scene):
    def construct(self):
        xs = (-4.4, -1.4, 1.6)
        until(self, "finds hotels")
        G(self, LaggedStart(*[FadeIn(hotel(x, 0.9, 1.0), shift=DOWN * 0.3) for x in xs], lag_ratio=0.2), rt=0.8)
        until(self, "within budget")
        G(self, Create(check(xs[0] + 0.05, -0.55, 0.24)), Create(check(xs[1] + 0.05, -0.55, 0.24)),
          Create(cross(xs[2], -0.55, 0.24, TERRA)), FadeIn(L("under budget", -2.9, -1.3)), rt=0.5)
        until(self, "says why")
        G(self, FadeIn(tag("parking", xs[0], -2.2, 32)), FadeIn(tag("on route", xs[1], -2.2, 32)), rt=0.4)
        until(self, "goes over", lead=0.6)
        track = Rectangle(width=2.6, height=0.3, stroke_color=INK, stroke_width=3, fill_opacity=0).move_to([4.6, 0.4, 0])
        fill = Rectangle(width=2.2, height=0.3, fill_color=INK, fill_opacity=1, stroke_width=0).move_to([4.4, 0.4, 0])
        G(self, FadeIn(track), FadeIn(fill), FadeIn(L("budget", 4.6, 1.1)), FadeIn(L("suggest a change", 4.6, -0.4, 32)), rt=0.5)
        finish(self)


class B04C_Places(Scene):
    def construct(self):
        ys = (1.6, 0.3, -1.0)
        until(self, "what to see")
        cols = VGroup(*[card(x, 0.1, 2.2, 4.0) for x in (-0.6, 2.0, 4.6)])
        G(self, FadeIn(cols), *[FadeIn(L(f"Day {i + 1}", x, 2.55)) for i, x in enumerate((-0.6, 2.0, 4.6))], rt=0.5)
        icons = [lambda x, y: wave(x, y + 0.15), lambda x, y: fort(x, y, 0.8), lambda x, y: plate(x, y, 0.45)]
        names = ["beaches", "forts", "veg food"]
        for i, (n, cue) in enumerate(zip(names, ["beaches", "forts", "vegetarian food"])):
            until(self, cue, lead=0.5 if i < 2 else 0.9)
            G(self, FadeIn(tag(n, -4.6, ys[i], 34)), FadeIn(icons[i](-0.6 + i * 2.6, 0.3)),
              FadeIn(icons[(i + 1) % 3](-0.6 + i * 2.6, -1.1)), rt=0.35)
        G(self, FadeIn(L("example", 2.0, -2.6, 32, DIM)), rt=0.3)
        finish(self)


class B04D_Day(Scene):
    def construct(self):
        centres = ((-4.0, 0.6), (-0.6, 1.2), (2.6, 0.4))
        until(self, "groups nearby")
        areas = VGroup(*[DashedVMobject(Circle(radius=1.1, stroke_color=DIM, stroke_width=4), num_dashes=20).move_to([x, y, 0]) for x, y in centres])
        pins = VGroup(*[pin(x + dx, y + dy, 0.2, INK) for x, y in centres for dx, dy in ((-0.4, -0.4), (0.3, -0.1), (-0.05, 0.25))])
        G(self, Create(areas), FadeIn(pins), FadeIn(L("by area", -0.6, 2.9)), rt=0.6)
        until(self, "opening hours")
        G(self, FadeIn(clock(-4.0, -1.6, 0.4)), FadeIn(L("open hours", -4.0, -2.6)), rt=0.4)
        until(self, "travel times")
        link = arrow([-2.9, 0.7, 0], [-1.7, 1.1, 0])
        link2 = arrow([0.5, 1.1, 0], [1.5, 0.6, 0])
        G(self, Create(link), Create(link2), FadeIn(L("travel time", -0.6, -1.0)), rt=0.4)
        until(self, "meal breaks", lead=0.5)
        G(self, FadeIn(plate(4.8, -1.4, 0.45)), FadeIn(L("meals", 4.8, -2.4)), rt=0.4)
        finish(self)

class B05_Deliver(Scene):
    def construct(self):
        self.add(ground(-2.4))
        xs = (-4.8, -1.6, 1.6, 4.8)
        until(self, "GitHub repository")
        G(self, FadeIn(repo_crate(xs[0], -1.4), shift=DOWN * 0.4), FadeIn(L("repository", xs[0], -3.0)), rt=0.5)
        until(self, "a React")
        win = VGroup(window(xs[1], -0.2, 2.4, 1.7), rows(xs[1] - 0.9, 0.1, [1.6, 1.2, 1.4]))
        G(self, FadeIn(win, shift=DOWN * 0.3), FadeIn(L("web app", xs[1], -1.7 - 1.3)), rt=0.5)
        until(self, "tests, and")
        G(self, FadeIn(VGroup(card(xs[2], -0.4, 1.4, 1.4), check(xs[2] + 0.05, -0.4, 0.3))), FadeIn(L("tests", xs[2], -3.0)), rt=0.5)
        until(self, "an evaluation report")
        G(self, FadeIn(binder(xs[3], -0.5)), FadeIn(L("eval report", xs[3], -3.0)), rt=0.5)
        finish(self)


class B06_Shelves(Scene):
    def construct(self):
        shelf1 = Line([-5.8, 0.6, 0], [3.0, 0.6, 0], color=KRAFT_EDGE, stroke_width=10)
        shelf2 = Line([-5.8, -2.0, 0], [3.0, -2.0, 0], color=KRAFT_EDGE, stroke_width=10)
        self.add(shelf1, shelf2, L("core", -4.9, 2.4, 38), L("also", -4.9, -0.2, 38))
        until(self, "save, share")
        core = VGroup(*[block(-5.0 + i * 1.5, 1.0, 1.3, 0.8) for i in range(6)])
        G(self, LaggedStart(*[FadeIn(b, shift=DOWN * 0.4) for b in core], lag_ratio=0.15), rt=0.9)
        until(self, "replan for")
        later = VGroup(*[block(-5.0 + i * 1.5, -1.6, 1.3, 0.8, fill=DARK_L) for i in range(6)])
        G(self, LaggedStart(*[FadeIn(b, shift=DOWN * 0.4) for b in later], lag_ratio=0.15), rt=0.9)
        until(self, "voice", lead=1.2)
        G(self, FadeIn(sheet(4.9, -0.4, 1.4, 1.8, 3), shift=LEFT * 0.3), FadeIn(L("full list", 4.9, -1.85)), rt=0.6)
        finish(self)


# ═════════════════════════════ Q2 — why anyone would care ═════════════════════════════
class B07_Alts(Scene):
    def construct(self):
        until(self, "Wanderlog")
        G(self, FadeIn(folded_map(-3.4, -0.2, 1.3)), FadeIn(L("Wanderlog", -3.4, 2.2, 40)), rt=0.6)
        until(self, "you add")
        cur = cursor(-3.0, 0.2)
        G(self, FadeIn(cur, shift=UP * 0.3), rt=0.3)
        G(self, FadeIn(pin(-3.25, 0.25, 0.26, TERRA), shift=DOWN * 0.2), FadeIn(L("you add", -3.4, -1.9)), rt=0.4)
        until(self, "Roadtrippers")
        r2 = road([1.0, -0.6, 0], [6.0, -0.6, 0])
        ring2 = DashedVMobject(Circle(radius=0.75, stroke_color=INK, stroke_width=4), num_dashes=18).move_to([3.5, -0.6, 0])
        G(self, Create(r2), FadeIn(L("Roadtrippers", 3.5, 2.2, 40)), Create(ring2), rt=0.6)
        until(self, "you pick")
        G(self, FadeIn(pin(3.5, -0.6, 0.28, TERRA), shift=DOWN * 0.2), FadeIn(L("you pick", 3.5, -1.75)), rt=0.4)
        finish(self)


class B08_Rule(Scene):
    def construct(self):
        self.add(day_road())
        ticks = VGroup(*[Line([x, ROAD_Y - 0.35, 0], [x, ROAD_Y + 0.35, 0], color=INK, stroke_width=6) for x in DAY_X[1:3]])
        self.add(ticks)
        until(self, "as rules")
        gates = VGroup()
        for i in range(3):
            cx = (DAY_X[i] + DAY_X[i + 1]) / 2
            gates.add(VGroup(Line([cx - 0.7, ROAD_Y + 0.3, 0], [cx - 0.7, ROAD_Y + 1.5, 0], color=INK, stroke_width=6),
                             Line([cx + 0.7, ROAD_Y + 0.3, 0], [cx + 0.7, ROAD_Y + 1.5, 0], color=INK, stroke_width=6),
                             Line([cx - 0.8, ROAD_Y + 1.5, 0], [cx + 0.8, ROAD_Y + 1.5, 0], color=INK, stroke_width=8)))
        marks = VGroup(*[check((DAY_X[i] + DAY_X[i + 1]) / 2 + 0.05, ROAD_Y + 2.05, 0.26) for i in range(3)])
        G(self, LaggedStart(*[Create(g) for g in gates], lag_ratio=0.2), FadeIn(L("budget + limits", 0.0, 2.9, 38)), rt=0.9)
        G(self, LaggedStart(*[Create(m) for m in marks], lag_ratio=0.25), rt=0.6)
        until(self, "every choice")
        pins = VGroup(*[pin(x, ROAD_Y - 0.15, 0.26, TERRA) for x in DAY_X[1:3]])
        why = VGroup(*[VGroup(card(x, ROAD_Y - 1.4, 1.2, 0.6), L("why", x, ROAD_Y - 1.4, 32)) for x in DAY_X[1:3]])
        G(self, FadeIn(pins), FadeIn(why, shift=UP * 0.2), rt=0.6)
        finish(self)


class B09_Real(Scene):
    def construct(self):
        a, b = np.array([-4.6, -0.9, 0]), np.array([4.6, -0.9, 0])
        G(self, FadeIn(L("real route · OSRM · 2026-10-23", 0.0, -3.0, 34)), FadeIn(L("OpenStreetMap", 0.0, 2.6, 40)), rt=0.5)
        until(self, "Ahmedabad to Goa")
        G(self, Create(road(a, b)), FadeIn(pin(a[0], a[1] + 0.15, 0.32)), FadeIn(pin(b[0], b[1] + 0.15, 0.32)),
          FadeIn(L("Ahmedabad", a[0], -2.0, 38)), FadeIn(L("Goa", b[0], -2.0, 38)), rt=0.8)
        until(self, "1,036")
        span = VGroup(Line([a[0], 0.5, 0], [b[0], 0.5, 0], color=KRAFT_EDGE, stroke_width=5),
                      Line([a[0], 0.3, 0], [a[0], 0.7, 0], color=KRAFT_EDGE, stroke_width=5),
                      Line([b[0], 0.3, 0], [b[0], 0.7, 0], color=KRAFT_EDGE, stroke_width=5))
        G(self, Create(span), FadeIn(L("1,036 km", 0.0, 1.3, 54), shift=DOWN * 0.2), rt=0.5)
        until(self, "12.7 hours")
        c = car(a[0] + 0.6, a[1] - 0.05, 0.7)
        G(self, FadeIn(c), FadeIn(L("12.7 h driving", 0.0, -0.1, 44)), rt=0.4)
        G(self, c.animate.move_to([b[0] - 1.2, c.get_center()[1], 0]), rt=1.6, rate_func=smooth)
        finish(self)


class B10_Days(Scene):
    def construct(self):
        self.add(day_road(), L("Ahmedabad", DAY_X[0] + 0.7, ROAD_Y - 0.8, 34), L("Goa", DAY_X[3] - 0.3, ROAD_Y - 0.8, 34))
        until(self, "five-hour")
        G(self, FadeIn(L("5 h limit", 0.0, 2.6, 44)), rt=0.5)
        until(self, "three driving days")
        ticks = VGroup(*[Line([x, ROAD_Y - 0.35, 0], [x, ROAD_Y + 0.35, 0], color=INK, stroke_width=6) for x in DAY_X[1:3]])
        G(self, Create(ticks), FadeIn(L("3 days", 0.0, 1.6, 40)), rt=0.5)
        beds = VGroup(*[VGroup(pin(x, ROAD_Y + 0.15, 0.28, TERRA), bed(x, ROAD_Y - 1.2, 0.7)) for x in DAY_X[1:3]])
        G(self, FadeIn(beds, shift=DOWN * 0.2), FadeIn(L("constructed", 0.0, -3.1, 32, DIM)), rt=0.6)
        finish(self)


# ═════════════════════════════ Q3 — who opens it ═════════════════════════════
class B11_Reader(Scene):
    def construct(self):
        self.add(ground(-1.9))
        G(self, FadeIn(suitcase(-0.8, -0.9, 1.4), shift=UP * 0.3), FadeIn(car_key(1.0, -1.05, 1.1)),
          FadeIn(L("traveller", 0.0, -2.8, 40)), rt=0.6)
        until(self, "on a budget", lead=0.6)
        coins = VGroup(*[Circle(radius=0.32, fill_color=BOX_R, fill_opacity=1, stroke_color=INK, stroke_width=4)
                         .move_to([3.0, -1.5 + i * 0.22, 0]) for i in range(3)])
        G(self, LaggedStart(*[FadeIn(c, shift=DOWN * 0.3) for c in coins], lag_ratio=0.25),
          FadeIn(L("on a budget", 0.0, 1.6, 38)), rt=0.6)
        finish(self)


class B12_Sixty(Scene):
    def construct(self):
        base, sweep = ring(-4.6, 0.6, 0.85)
        self.add(base, L("60 s", -4.6, -0.75, 38))
        win = window(1.6, 0.2, 7.0, 4.4)
        self.add(win)
        until(self, "enter a trip")
        G(self, Create(sweep, run_time=1.0), FadeIn(rows(-1.5, 1.4, [2.0, 1.4])), rt=1.0)
        until(self, "day-by-day plan")
        r = road([-1.4, -0.5, 0], [4.6, -0.5, 0], 12)
        tk = VGroup(*[Line([x, -0.8, 0], [x, -0.2, 0], color=INK, stroke_width=5) for x in (0.6, 2.6)])
        G(self, Create(r), Create(tk), rt=0.6)
        until(self, "open one choice")
        cur = cursor(2.75, -0.6)
        pop = VGroup(card(2.6, 0.9, 1.6, 0.8), L("why", 2.6, 0.9, 34))
        G(self, FadeIn(cur, shift=UP * 0.2), rt=0.3)
        G(self, FadeIn(pop, shift=UP * 0.2), rt=0.4)
        until(self, "constructed mock-up")
        G(self, FadeIn(L("constructed · mock-up", 1.6, -2.55, 34, DIM)), rt=0.4)
        finish(self)


# ═════════════════════════════ how it works ═════════════════════════════
class B13_Rule(Scene):
    def construct(self):
        div = DashedLine([0, 2.6, 0], [0, -2.6, 0], color=GHOST, stroke_width=4)
        self.add(div)
        G(self, FadeIn(sheet(-3.4, 0.4, 1.6, 2.0, 3)), FadeIn(L("AI plans", -3.4, -1.3, 40)), rt=0.5)
        until(self, "code checks", lead=0.8)
        stack, lights = Iso(3.2, -0.6, 1.0).server(-0.7, -0.7, 0)
        G(self, FadeIn(stack), FadeIn(L("code checks", 3.2, -1.9, 40)), rt=0.5)
        finish(self)


class B14_Tools(Scene):
    def construct(self):
        until(self, "structured requirements")
        req = sheet(-5.0, 0.6, 1.4, 1.8, 3)
        struct = VGroup(card(-2.3, 0.6, 1.8, 1.8), rows(-3.0, 1.1, [1.3, 1.0, 1.2], gap=0.45, h=0.18, color=INK))
        G(self, FadeIn(req), rt=0.4)
        G(self, FadeIn(struct, shift=RIGHT * 0.3), FadeIn(L("structured", -2.3, -0.85)), rt=0.5)
        until(self, "asks for anything")
        G(self, FadeIn(bubble("dates?", -3.6, 2.6, 34), shift=UP * 0.2), rt=0.4)
        for i, (n, cue) in enumerate(zip(["fares", "hotels", "places"], ["fares", "hotels", "places"])):
            until(self, cue, lead=0.8)
            y = 1.5 - i * 1.5
            G(self, FadeIn(Iso(2.6, y - 0.35, 0.8).mcp(-0.65, -0.65, 0)), FadeIn(L(n, 4.6, y)), rt=0.35)
        finish(self)


class B15_Checks(Scene):
    def construct(self):
        stack, lights = Iso(-4.4, -1.0, 1.0).server(-0.7, -0.7, 0)
        self.add(stack, lights)
        names = ["budget", "hours", "overlaps", "timing"]
        cues = ["totals the budget", "checks opening hours", "overlaps", "travel times"]
        xs = (-1.4, 0.6, 2.6, 4.6)
        boxes = []
        for i, (n, cue, x) in enumerate(zip(names, cues, xs)):
            until(self, cue)
            bx = card(x, 0.6, 1.0, 1.0)
            boxes.append(bx)
            mark = [Create(check(x + 0.05, 0.6, 0.24))] if i < 3 else []
            G(self, FadeIn(bx), FadeIn(L(n, x, -0.4)), *mark, rt=0.35)
        until(self, "If a check fails")
        x_mark = cross(xs[3], 0.6, 0.24, TERRA)
        G(self, Create(x_mark), rt=0.4)
        until(self, "repair")
        loop = CurvedArrow([xs[3], 1.3, 0], [-3.2, 1.6, 0], angle=PI / 4, color=KRAFT_EDGE, stroke_width=6)
        G(self, Create(loop), FadeIn(L("repair", 0.6, 3.0)), rt=0.6)
        finish(self)


class B16_Labels(Scene):
    def construct(self):
        ys = (1.3, 0.0, -1.3)
        for y in ys:
            self.add(rows(-5.2, y, [4.6], h=0.24))
        for n, cue, y in zip(["verified", "estimated", "AI suggestion"], ["verified", "estimated", "AI suggestion"], ys):
            until(self, cue)
            G(self, FadeIn(tag(n, 2.6, y, 36), shift=LEFT * 0.4), rt=0.35)
        finish(self)


class B17_Chat(Scene):
    def construct(self):
        win = window(2.2, 0.0, 6.4, 4.2)
        self.add(win)
        days = VGroup(*[block(0.0 + i * 2.2, 0.2, 1.7, 0.7, fill=DARK_L) for i in range(3)])
        self.add(days, *[L(f"Day {i + 1}", 0.0 + i * 2.2, -0.65) for i in range(3)])
        until(self, "add a beach day")
        G(self, FadeIn(bubble("add a beach day", -4.4, 1.4, 34), shift=UP * 0.2), rt=0.4)
        until(self, "cheaper hotel")
        G(self, FadeIn(bubble("cheaper hotel", -4.4, 0.0, 34), shift=UP * 0.2), rt=0.4)
        until(self, "previews", lead=0.9)
        hl = SurroundingRectangle(days[1], color=TERRA, stroke_width=6, buff=0.12)
        G(self, Create(hl), FadeIn(L("preview", 2.0, 1.4)), Create(check(3.8, 1.45, 0.24)), FadeIn(L("save", 4.6, 1.4)), rt=0.5)
        finish(self)


# ═════════════════════════════ Q4 — what it proves ═════════════════════════════
class B18_Proves(Scene):
    def construct(self):
        names = ["contracts", "agent loop", "grounding", "verify", "evaluate"]
        cues = ["prompt contracts", "agent loop", "source grounding", "verification in code", "and evaluation"]
        xs = (-5.0, -2.5, 0.0, 2.5, 5.0)
        for n, cue, x in zip(names, cues, xs):
            until(self, cue, lead=0.9)
            G(self, FadeIn(block(x, 0.3, 1.8, 1.4), shift=DOWN * 0.3), FadeIn(Dot([x - 0.6, 0.75, 0], radius=0.1, color=TERRA)),
              FadeIn(L(n, x, -0.9)), rt=0.35)
        finish(self)


class B19_Eval(Scene):
    def construct(self):
        until(self, "tests and")
        G(self, FadeIn(binder(-5.0, 0.3)), FadeIn(L("tests", -5.0, -1.0)), rt=0.5)
        until(self, "twenty-trip")
        grid = VGroup(*[card(-2.4 + c * 1.1, 1.6 - r * 0.8, 0.85, 0.55) for r in range(4) for c in range(5)])
        G(self, LaggedStart(*[FadeIn(g) for g in grid], lag_ratio=0.04), FadeIn(L("20 trips", -0.2, -2.0)), rt=0.9)
        until(self, "counting")
        marks = VGroup(*[cross(grid[i].get_center()[0], grid[i].get_center()[1], 0.13, TERRA, 5) for i in (3, 8, 14)])
        G(self, LaggedStart(*[Create(m) for m in marks], lag_ratio=0.2), rt=0.6)
        until(self, "every miss", lead=0.8)
        G(self, FadeIn(sheet(4.8, 0.3, 1.4, 1.8, 3)), FadeIn(L("eval report", 4.8, -1.0)), rt=0.5)
        finish(self)


# ═════════════════════════════ Q5 — in, out, first ═════════════════════════════
BIN_X = (-3.2, 3.2)


def bins2():
    out = VGroup()
    for x in BIN_X:
        back, front = Iso(x, -1.6, 1.0).open_box(-0.8, -0.8, 0, 1.6, 1.6, 0.9)
        out.add(VGroup(plinth(x, -1.6, -0.8, -0.8, 1.6, 1.6), back, front))
    return out, VGroup(*[L(n, x, -3.1, 38) for n, x in zip(["In", "Out"], BIN_X)])


class B20_InOut(Scene):
    def construct(self):
        bx, labels = bins2()
        self.add(bx, labels)
        until(self, "In scope")
        items = VGroup(*[Iso(BIN_X[0] + dx, -1.1 + dy, 1.0).box(-0.25, -0.25, 0, 0.5, 0.5, 0.4) for dx, dy in ((-0.45, 0.1), (0.35, 0.05), (-0.05, 0.45))])
        for it in items:
            it.set_z_index(1)
        G(self, LaggedStart(*[FadeIn(i, shift=DOWN * 1.0, rate_func=ease_in) for i in items], lag_ratio=0.3), FadeIn(L("everything", BIN_X[0], 1.6)), rt=0.9)
        until(self, "book or pay")
        cardp = VGroup(RoundedRectangle(width=1.5, height=0.95, corner_radius=0.1, fill_color=DARK_L, fill_opacity=1, stroke_color=INK, stroke_width=4),
                       Rectangle(width=1.5, height=0.18, fill_color=BAR2, fill_opacity=1, stroke_width=0).shift(UP * 0.2)).move_to([BIN_X[1], 0.9, 0])
        G(self, FadeIn(cardp, shift=DOWN * 0.3), rt=0.4)
        G(self, Create(cross(BIN_X[1], 0.9, 0.5, TERRA, 9)), FadeIn(L("no booking", BIN_X[1], 2.1)), rt=0.5)
        finish(self)


class B21_First(Scene):
    def construct(self):
        xs = (-3.6, 0.0, 3.6)
        self.add(L("First", 0.0, 3.0, 40))
        until(self, "plan checker")
        days = VGroup(*[card(x, 0.3, 2.6, 2.4) for x in xs])
        G(self, FadeIn(days), *[FadeIn(L(f"Day {i + 1}", x, 1.9)) for i, x in enumerate(xs)],
          *[FadeIn(rows(x - 0.9, 0.8, [1.8, 1.4, 1.6], gap=0.45, h=0.18)) for x in xs], rt=0.6)
        until(self, "plants a closed place")
        G(self, FadeIn(tag("closed", xs[0], -0.5, 32)), rt=0.4)
        until(self, "over-budget day")
        track = Rectangle(width=2.0, height=0.26, stroke_color=INK, stroke_width=3, fill_opacity=0).move_to([xs[2], -0.5, 0])
        over = Rectangle(width=2.4, height=0.26, fill_color=INK, fill_opacity=1, stroke_width=0).move_to([xs[2] + 0.2, -0.5, 0])
        G(self, FadeIn(track), FadeIn(over), rt=0.4)
        until(self, "flags both", lead=0.6)
        G(self, Create(cross(xs[0], -1.8, 0.24, TERRA)), Create(cross(xs[2], -1.8, 0.24, TERRA)),
          Create(check(xs[1] + 0.05, -1.8, 0.24)), FadeIn(L("test passes", 0.0, -2.8)), rt=0.5)
        finish(self)


# ═════════════════════════════ Q6 — what could sink it ═════════════════════════════
class B22_Risk(Scene):
    def construct(self):
        xs = (-4.0, 0.0, 4.0)
        self.add(*[plinth(x, -1.4, -0.6, -0.6, 1.2, 1.2) for x in xs])
        until(self, "Google's APIs")
        c1 = Iso(xs[0], -1.4, 1.0).box(-0.6, -0.6, 0, 1.2, 1.2, 0.9)
        G(self, FadeIn(c1, shift=DOWN * 0.5), FadeIn(L("places, hours", xs[0], -3.0)), rt=0.5)
        until(self, "not flight or hotel prices")
        gaps = VGroup()
        for x in xs[1:]:
            faces = Iso(x, -1.4, 1.0).box(-0.6, -0.6, 0, 1.2, 1.2, 0.9)
            gaps.add(VGroup(*[DashedVMobject(f.copy().set_fill(opacity=0).set_stroke(DIM, 4), num_dashes=14) for f in faces]))
        G(self, Create(gaps), FadeIn(L("flight prices", xs[1], -3.0)), FadeIn(L("hotel prices", xs[2], -3.0)),
          FadeIn(L("?", xs[1], 1.3, 60)), FadeIn(L("?", xs[2], 1.3, 60)), rt=0.6)
        until(self, "Amadeus", lead=0.6)
        G(self, FadeIn(tag("Amadeus: closed July 2026", 0.0, 2.6, 32)), rt=0.4)
        finish(self)


class B23_Guard(Scene):
    def construct(self):
        until(self, "flight API")
        G(self, FadeIn(tag("flight API", -4.2, 1.8, 36), shift=DOWN * 0.2), rt=0.4)
        until(self, "hotel partner")
        G(self, FadeIn(tag("hotel API", -4.2, 0.6, 36), shift=DOWN * 0.2), rt=0.4)
        until(self, "estimates")
        G(self, FadeIn(rows(-5.6, -0.6, [3.0], h=0.26)), FadeIn(L("estimate", -4.2, -1.3, 38)), rt=0.4)
        until(self, "test coverage", lead=0.6)
        grid = VGroup(*[card(0.6 + c * 0.95, 1.5 - r * 0.75, 0.75, 0.5) for r in range(4) for c in range(5)])
        G(self, LaggedStart(*[FadeIn(g) for g in grid], lag_ratio=0.04), FadeIn(L("coverage first", 2.5, -1.8)), rt=0.9)
        finish(self)


# ═════════════════════════════ Q7 — why this project ═════════════════════════════
def pile_base(x, y=-2.2):
    return Rectangle(width=2.6, height=0.22, fill_color=DARK_L, fill_opacity=1, stroke_width=0).move_to([x, y, 0])


def pile(x, n, y=-2.2):
    return VGroup(*[block(x, y + 0.42 + i * 0.62, 2.2, 0.56) for i in range(n)])


class B24_Why(Scene):
    def construct(self):
        self.add(road([-6.0, -2.4, 0], [6.0, -2.4, 0]))
        until(self, "backend and AI")
        G(self, FadeIn(car(-3.6, -2.4, 1.0)), FadeIn(suitcase(-1.4, -1.85, 0.8)), rt=0.5)
        until(self, "mostly learning", lead=0.8)
        fulcrum = Polygon([3.0, -1.9, 0], [2.6, -1.3, 0], [3.4, -1.3, 0], fill_color=DARK_L, fill_opacity=1, stroke_width=0)
        beam = Line([1.0, -0.95, 0], [5.0, -1.55, 0], color=INK, stroke_width=8)
        b1 = block(1.6, -0.7, 0.8, 0.5)
        b2 = block(4.4, -1.0, 1.4, 0.9, fill=DARK_L)
        G(self, FadeIn(VGroup(fulcrum, beam, b1, b2)), FadeIn(L("know", 1.6, 0.0)), FadeIn(L("learn", 4.4, 0.0)), rt=0.6)
        finish(self)


class B25_Have(Scene):
    def construct(self):
        self.add(pile_base(-3.0), L("already know", -3.0, 2.8, 40))
        blocks = pile(-3.0, 4)
        for blk, cue in zip(blocks, ["Python", "REST APIs", "data pipelines", "dashboards"]):
            until(self, cue)
            G(self, FadeIn(blk, shift=DOWN * 0.6), rt=0.35)
        until(self, "no public projects")
        faces = Iso(3.0, -1.7, 0.9).box(-0.6, -0.6, 0, 1.2, 1.2, 0.8)
        ghost = VGroup(*[DashedVMobject(f.copy().set_fill(opacity=0).set_stroke(DIM, 4), num_dashes=14) for f in faces])
        G(self, Create(ghost), FadeIn(L("no projects yet", 3.0, -3.0)), rt=0.5)
        until(self, "from scratch", lead=0.8)
        G(self, FadeIn(L("first build", 3.0, 1.0, 38)), rt=0.4)
        finish(self)


class B26_New(Scene):
    def construct(self):
        self.add(pile_base(-3.0), pile(-3.0, 4), L("already know", -3.0, 2.8, 40), pile_base(3.0))
        G(self, FadeIn(L("learning", 3.0, 2.8, 40)), rt=0.4)
        for i, cue in enumerate(["travel APIs", "agent tool loops", "constraint checking", "plan evaluation", "TypeScript"]):
            until(self, cue, lead=0.8)
            G(self, FadeIn(block(3.0, -2.2 + 0.42 + i * 0.62, 2.2, 0.56, fill=DARK_L), shift=DOWN * 0.6), rt=0.3)
        finish(self)


class B27_Exists(Scene):
    def construct(self):
        xs = (-3.2, 0.0, 3.2)
        self.add(L("exists today", 0.0, 3.0, 40))
        for x, n, cue in zip(xs, ["pitch", "brief", "route sample"], ["this pitch", "my brief", "route sample"]):
            until(self, cue)
            G(self, FadeIn(sheet(x, 1.2, 1.3, 1.6, 3)), FadeIn(L(n, x, 0.0)), rt=0.35)
        until(self, "Everything else")
        ghosts = VGroup(*[Rectangle(width=1.3, height=1.6, stroke_color=DIM, stroke_width=3, fill_opacity=0).move_to([x, -1.7, 0]) for x in xs])
        G(self, Create(ghosts), FadeIn(L("will build", 0.0, -3.0)), rt=0.6)
        finish(self)


class BOUT_Title(Scene):
    def construct(self):
        kicker = T("FINAL PROJECT PITCH  ·  INFO 7375", 32, DIM).move_to([0, 2.5, 0])
        name = T("TripMate", 110).move_to([0, 1.0, 0])
        self.add(kicker)
        G(self, FadeIn(name, shift=UP * 0.15), rt=0.6)
        rule = Line([-3.0, -0.3, 0], [3.0, -0.3, 0], color=TERRA, stroke_width=8)
        who = T("Smit Patel", 56).move_to([0, -1.3, 0])
        G(self, Create(rule), FadeIn(who), rt=0.6)
        finish(self)
