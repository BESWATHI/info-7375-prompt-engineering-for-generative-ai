# REVIEW — show-tell-ordertrail-pitch

**Project:** OrderTrail final project pitch video  
**Author:** Smit Patel — INFO 7375  
**Final review date:** 2026-10-11  
**Status:** Complete and approved for submission

This record documents the technical checks, revisions, and author approval of the final OrderTrail
pitch video. 
---

## Part 1 — machine checks (complete)

| Check | Tool | Result |
|---|---|---|
| Static pre-flight, all 26 Manim scenes, each run alone (as the gate runs it) | `static_scene_check.py` | CLEAN — earlier defects fixed (see "Fix history" below) |
| Pixel-true layout | `manim_layout_audit.py` | CLEAN — 0 errors, 0 warnings on the last pass |
| WCAG contrast, margins, text overlap | Gate W in `./art run` | passed |
| Frame-level visual QC on the compiled cut | `final_frame_check.py` (Gate V) | CLEAN — 52 frames, 0 BLOCKER, 0 MAJOR |
| Typography lock (size floor, contrast, overlap) | `type_check.py` (GATE T) | PASS — 26 beats, 0 FAILs |
| Narration timing vs scene length | kit `until()` / `finish()` pacing from measured Kokoro audio | every scene paced to its narration |
| Frame read-through | Claude, by eye, every beat at 50% and 90% | caught 4 problems no gate flagged (see below); all fixed and re-checked |
| Master file | `ffprobe` + `volumedetect` | 1920×1080, 24 fps, 260.0 s, h264 + AAC 48 kHz, 9.9 MB; mean −26.8 dB / max −3.5 dB (audio present and at level) |

Master: `final/show-tell-ordertrail-pitch.mp4`, with `final/show-tell-ordertrail-pitch.verified.json`.
Review cut with beat labels: `show-tell-ordertrail-pitch-slate.mp4`.

### Fix history (7 render passes; title-card waiver recorded below)

| Pass | Found by | Problem | Fix |
|---|---|---|---|
| stills | frame read | B01 pallet floated away from the hard hats; B02 third crate cut off; B06 labels hidden by dark blocks; B19 label on top of a window | repositioned before the first render |
| 1 | Gate V | 12 frames low contrast (pale kraft boxes, B17 tray, B22 faded pile); title card underfilled | dark plinths under kraft objects; dark tray; no faded pile; title card waiver |
| 2 | frame read | bin plinths covered the In / Out / First labels | labels moved down |
| 2–3 | GATE T | B04, B08, B10 "text" 40 px < 41 px floor — the handwriting scribbles on the pages | taller scribble waves |
| 4 | frame read | B06, B08, B12 last element still fading in at 90%; B18 empty plinths before their crates | cues moved earlier; plinths arrive with crates |
| 6 | frame read | BAI1 crates crowded, arrows ran into them | crates spread, arrows end above them |
| 7 | — | BAI1 reworded (Part 2, row 4) | re-voiced, re-rendered; all gates clean |

---

## Part 2 — review decisions already made (from the session, 2026-10-10 to 2026-10-11)

| # | Date | What was reviewed | Decision | What changed | Re-checked |
|---|---|---|---|---|---|
| 1 | 2026-10-10 | Version 1, `cc-ordertrail-pitch` (cc-explainer, 6:57) | **Rejected.** "i dont like what ever you generated … show files in python … all looks bad so please see my patch and create a video again." | Remade with the `show-tell` skill: my script read word for word, one drawing per "Picture:" note, no code or terminal on screen | new film, all gates |
| 2 | 2026-10-10 | Version 2 approach | Accepted the remake; drawn people replaced by objects (hard hats, clipboard, laptop) because the skill forbids person icons | — | frame read |
| 3 | 2026-10-11 | Version 2 content | **Requested a new section**: where AI is used in the project and how it helps | 3 beats (BAI1–BAI3), drafted by Claude in my voice, inserted after beat 5 | gates + frame read |
| 4 | 2026-10-11 | BAI1 wording | Approved wording that identifies column mapping as a possible extension, rather than a committed feature | BAI1 now presents it as "one possible extension" that I would confirm | gates + frame read |

---

## Part 3 — final author review (complete)

I approve the final OrderTrail pitch video for submission. The finished video communicates the
construction delivery problem, the proposed product, and the project’s main risk clearly. The
visual approach follows the direction of my script and “Picture:” notes, and the final presentation
is satisfactory.

The AI section explains the intended roles of code, Claude, and my own review. Column mapping
is presented as a possible extension that would require my confirmation. This wording keeps the
pitch accurate without treating that extension as a feature I have committed to build.

There are no outstanding issues or requested revisions. All work is complete.

| Review item | Final decision |
|---|---|
| Content and project explanation | Approved |
| Visuals and presentation | Approved |
| AI section and scope wording | Approved |
| Overall final video | Approved for submission |
| Outstanding revisions | None |

**Author approval:** Smit Patel, 2026-10-11. Final work confirmed complete and satisfactory.

---

## Part 4 — the AI / human split (per the course's Irreducibly Human note)

**Delegated to Claude (in Claude Code):** choosing and running the video skills; splitting the script
into beats; drawing every scene in Manim; voicing with local Kokoro; running the render gates and
fixing what they flagged; reading frames; drafting the three AI-section beats; and the initial review documentation. Codex helped polish this final review record based on my confirmation of completion.

**Retained by the author:**

- The project idea and the real problem behind it (a friend's construction company).
- The full pitch script and every "Picture:" note.
- Rejecting version 1 and saying why; asking for the AI section; the column-mapping decision.
- Watching the final and deciding whether it communicates the pitch, and whether to submit it.

**A review decision that improved understanding:**

After reviewing the first version, I requested a remake because it focused on the coding session
instead of explaining the problem and product in my pitch. The show-tell version follows my script
and uses drawings based on my “Picture:” notes. This change gives viewers a clearer path from
the construction delivery problem to OrderTrail’s proposed solution and why it matters. It improves
the explanation by making the project itself the focus of the video.

