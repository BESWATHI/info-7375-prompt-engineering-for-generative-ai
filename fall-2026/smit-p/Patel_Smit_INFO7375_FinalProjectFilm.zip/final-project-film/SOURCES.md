# SOURCES — show-tell-ordertrail-pitch

| Item | Where | Licence / owner |
|---|---|---|
| Script (8 beats + Picture notes) | Smit Patel, given in chat 2026-10-10 | author |
| Toolkit: `show-tell` skill, `iso_kit.py`, render gates | `brutalist.art` @ `b21f625` | instructor-provided toolkit |
| Manim Community v0.18.1 | pip | MIT |
| Narration voice | Kokoro-82M (local), voice `am_onyx` | Apache-2.0 |
| Font | EB Garamond | SIL OFL |
| Product names (Procore, Odoo) | named for comparison only | their owners |

**Synthetic narration disclosure:** the narration is a synthetic voice (Kokoro `am_onyx`) reading the
author's script. The video does not say so, to keep it on the pitch. This file is the disclosure.

**Third-party assets:** none beyond the tools above. Every drawing is original Manim code in
`scenes.py`; no stock images, music, icons or footage.

## What I made

- The project idea and the real problem behind it.
- The full 8-beat pitch script and every "Picture:" note (narration of beats B01–B22 is my script, verbatim).
- The review decisions: rejecting the first version, asking for the AI section, presenting column
  mapping as a possible extension (see REVIEW.md).

## What Claude contributed

- Claude (in Claude Code) chose the show-tell skill, split my script into drawn beats, drew every scene
  in Manim from my Picture notes, voiced it with local Kokoro, and ran the renders and gate checks.
- **The three "Where AI comes in" beats (BAI1–BAI3) were drafted by Claude** in my voice at my request
  (2026-10-11); I approved the final film.
- `SESSION.md` records a real Claude Code session from the first version of the film, in which Claude
  wrote the prototype data generator, check and tests from my prompts.
