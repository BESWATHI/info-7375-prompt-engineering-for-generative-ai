# BUILD-PROMPT — OrderTrail pitch film

## The prompts (to Claude Code, 2026-10-10/11)

1. "can you use cc-explainer skill and create a video for me" + my 8-beat pitch script with Picture notes
   → first version (cc-explainer); rejected (see REVIEW.md).
2. "i dont like what ever you generated find other video generator skills and create a video which show
   as my pitch … show files in python … all looks bad so please see my patch and create a video again"
   → this film, built with the `show-tell` skill: script word for word, one drawing per Picture note.
3. "can you add a section where i will add ai in this project to complete and how it will help"
   → beats BAI1–BAI3 (drafted by Claude in my voice), inserted after beat 5.
4. Follow-up: present column mapping as "one possible extension" (BAI1 re-voiced).

## Commands

From `brutalist.art` (revision `b21f625`), with `REEL` = the reel folder
(`youtube/show-tell-ordertrail-pitch/` in the course repo):

```bash
cd "$REEL" && python3 make_sheet.py                                   # beat_sheet.json from the script
cd /path/to/brutalist.art
python3 runtime/scripts/generate_audio_kokoro.py "$REEL"             # Kokoro am_onyx; audio is the clock
./art run   "$REEL" --height 1080                                    # Gates A, W, B, V + review cut
python3 runtime/scripts/type_check.py "$REEL"                        # GATE T
./art final "$REEL" --height 1080 --out "$REEL/final"                # master
```

To change one scene: edit `scenes.py`, move `manim/<BEAT>.mp4` aside, re-run `./art run`.
To change narration: edit `make_sheet.py`, re-run it, then
`generate_audio_kokoro.py "$REEL" --only <BEAT>` before `./art run`.
