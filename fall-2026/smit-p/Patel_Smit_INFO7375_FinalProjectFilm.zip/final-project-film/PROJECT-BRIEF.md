# PROJECT-BRIEF — TripMate

**Author:** Smit Patel · INFO 7375 · Final project pitch · 2026-10-23
**Working title:** TripMate, an AI planner for the whole trip
**Target role:** backend or AI software engineer

## Executive summary

TripMate will be a trip-planning web app that plans a whole trip: how to get there, where to stay, and
what to see and do each day. You give it where you start and where you are going, your dates, who is
travelling, your budget and your interests. It compares driving, buses, trains and flights against your
budget; finds hotels within budget near the places you will visit; builds a day-by-day plan of places
and activities from your interests, grouped by area with real opening hours and travel times; and, if
you drive, splits a long road trip into driving days with overnight stops. AI plans and explains; plain
code checks every price, opening hour, travel time and total before a plan is shown. Nothing is built
yet. What exists today is this brief and one real route sample (Ahmedabad to Goa, fetched 2026-10-23).

---

## 1. What is it?

**One sentence:** TripMate is an AI planner for the whole trip — getting there, where to stay, and what
to see and do each day — built from your dates, budget and interests, and checked by code.

**When it is done, it will be:** a public GitHub repository containing a web app (React and TypeScript
front end, Node.js and TypeScript back end, PostgreSQL, Claude through the Anthropic API, and travel
data APIs), a test suite, and an evaluation report on 20 test trips.

**Everything it will do** (the full project; any cut is logged in FRICTIONAL.md):

- **Trip setup:** start, destination, dates, travellers, budget and currency, interests, food
  preferences, pace, accessibility needs.
- **Getting there:** compares driving, buses, trains and flights by price and time, and suggests the best
  fit for the budget.
- **Where to stay:** finds hotels within budget, near the places you will visit, with a reason for each
  (price, location, parking).
- **What to see and do:** a day-by-day plan of places and activities that Claude builds from your
  interests (for example, for Goa: beaches, forts and vegetarian food), grouped by area, with real
  opening hours, travel times between stops, and meal breaks.
- **Road trips:** splits a long drive into driving days by a daily limit, picks where to sleep each
  night and why, and adds rest, meal, fuel and EV-charging breaks.
- **Budget:** a breakdown (transport, stay, food, activities, contingency) and an optimizer that
  suggests a change when the total goes over, saying what you give up.
- **Checks:** overlaps, closed places, impossible timing, driving limits, budget totals.
- **Chat edits:** "add a beach day", "find a cheaper hotel" — previewed before they are saved.
- **Also:** save, share and export trips; weather replanning; packing lists; balancing group
  preferences; voice requests.

## 2. Why would anyone care?

Planning a trip today means switching between flight and hotel sites, maps, blogs and a calculator,
and still guessing what to do when you arrive.

Two real alternatives (checked 2026-10-23, see SOURCES.md):

- **Wanderlog** has an AI assistant (described by its co-founder as ChatGPT with a map) and a budget
  tracker, but you add each suggested place to your itinerary and enter your expenses yourself.
- **Roadtrippers** shows where to look for a stop a set driving time along a route, but you choose and
  place each stop yourself.

**What TripMate does that they do not:** it builds the whole plan for you — travel, hotels and each
day's places — treats your budget and limits as rules the plan must pass, and gives a reason for every
choice, with prices, hours and travel times from data rather than from the model.

## 3. Who opens it, and what do they do?

- **Reader:** the end user, a traveller planning a trip on a budget.
- **First sixty seconds:** they enter a trip, get a day-by-day plan with travel, hotels and things to
  do, and open one choice to read why it was made.

## 4. What does it prove about me?

Skills from this course: a **prompt contract** (Claude must return the plan in a fixed structure), an
**agent loop** with tool calls (fares, hotels, places, routes), **source grounding** (every price,
place and time comes from a data source, and each detail is labelled verified, estimated or AI
suggestion), **verification** in code (budget, opening hours, overlaps, travel times, driving limits),
and **evaluation**.

**Evidence I will produce:** the test suite, and an evaluation on 20 test trips that counts over-budget
plans, closed places and impossible timing, compared with a plain chat answer for the same trips. I
will report every miss.

**What a reviewer can fairly conclude:** that I can build a tool-using AI feature whose output is
checked by code and measured. Not that I have shipped a production travel product.

## 5. What is in, what is out, what comes first?

- **In:** everything in section 1.
- **Out (deliberately):** TripMate will not book or pay for anything; you book with the provider.
- **First piece:** the plan checker, in plain code with no AI. Given a day-by-day plan, it flags closed
  places, overlaps and over-budget days. **You will know it ran** when a test plants one closed place
  and one over-budget day and the checker flags both, and nothing else.

## 6. What could sink it?

**Price data.** Google's Maps Platform APIs (Places, Routes) give places, ratings, opening hours and
travel times, but Google offers no public API for flight or hotel prices (its QPX Express flight API
closed in 2018). Amadeus closed its free self-service developer APIs on July 17, 2026. **What I will
do:** use Google for places, hours and travel times; use a flight API such as Duffel and a hotel
partner API for prices; label any price I cannot confirm as an estimate; and test data coverage on all
20 evaluation trips before building on top of it.

## 7. Why this project?

I am aiming for backend and AI engineering roles, and this project needs both. It is **mostly
learning**: I am building it from scratch.

- **Already know (knowledge, no built work yet):** Python, REST APIs, data pipelines and dashboards. I
  have no public projects to point to yet, so TripMate's repository will be my first evidence for these
  skills.
- **New to me:** travel data APIs, agent loops with tool calls, constraint checking, plan evaluation,
  and a TypeScript back end.

---

## Exists today

- This brief (2026-10-23).
- One real route sample: OpenStreetMap's public router (OSRM demo server), Ahmedabad to Panaji (Goa),
  about 1,036 km and 12.7 hours of driving with no traffic or breaks, fetched 2026-10-23T20:42Z.
  File: `evidence/osrm-ahmedabad-panaji-2026-10-23.json`.

## Will exist

- The plan checker and its tests (first piece).
- Trip setup, travel-mode comparison, hotel search, the places-and-activities plan, road-trip splitting
  and breaks, the budget and optimizer.
- Chat edits; save, share and export; weather replanning, packing lists, group preferences and voice.
- The 20-trip evaluation report.
