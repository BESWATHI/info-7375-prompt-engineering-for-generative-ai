# Project Brief — OrderTrail

**Smit Patel · INFO 7375 · working title: OrderTrail**

**1. What is the problem?** On a construction site, a late delivery can leave a crew standing around and a schedule slipping. A friend who runs a small construction company finds it hard to track material orders, late deliveries, and shipments that don't match what was ordered.

**2. What is it?** A material order tracker for small construction companies. It links requests, purchase orders, deliveries and invoices from spreadsheet exports, flags delays and mismatches, estimates arrival windows from past lead times, and explains every alert with the records behind it. Deliverable: a GitHub repository with a web dashboard, a synthetic sample dataset and an evaluation report.

**3. Why would anyone care?** Procore is a full construction platform; Odoo's free purchasing module means adopting a whole ERP. Small teams track orders in spreadsheets and messages. OrderTrail works on the spreadsheets they already keep, checks the three-way match (order, delivery, invoice), and shows exactly which records caused each alert.

**4. Who opens it, and what happens in the first sixty seconds?** The person who orders materials for a small construction company; the second reader is an engineering hiring manager. They run one command, load the sample data, and see open orders by job site, late deliveries and flagged mismatches. Clicking an alert opens the purchase order and delivery record that disagree. (The dashboard in the film is a mock-up.)

**5. How does it work, and what does it prove?** Code calculates every number; Claude only explains. Timings, anomaly checks and estimates run in Python. Claude turns findings into plain language under a prompt contract that forbids any number not in the records, and a checker verifies every citation before an explanation is shown. AI also may suggest how spreadsheet columns map to orders, deliveries and invoices (a possible extension, confirmed by me). It proves prompt contracts, verification, source grounding and evaluation; the evidence is a test suite and an evaluation log.

**6. What is in scope, out of scope, and first?** In: order dashboard by job site, order timeline, five anomaly checks including the three-way match, arrival estimates. Out: no live accounting systems, no contacting suppliers; uploaded files only. First: load synthetic data and flag one planted quantity mismatch; a test confirms the flagged order is the planted one.

**7. Why this project?** It is a real problem someone I know faces, and it lets me show backend work while learning what this course teaches. No real company data; everything is synthetic. **Biggest risk:** I design the synthetic data, so the app could look accurate only because the data fits it. Guard: messy data (unreliable suppliers, partial deliveries, missing dates), backtesting estimates against hidden delivery dates, reporting misses honestly, and saying "insufficient history" when data is thin.

## Exists today
- This pitch film and this project brief.
- Already have: Python REST APIs, data pipelines and dashboards; co-op monitoring dashboards on a streaming data pipeline; public repositories linked in the README.

## Will exist
- The OrderTrail repository: data loading, five anomaly checks including the three-way match, arrival estimates, and the web dashboard by job site.
- The synthetic sample dataset (messy by design) and the backtest.
- Claude explanations under a prompt contract, with the citation checker.
- The test suite and evaluation report.
- New to me: construction procurement, prompt contracts, citation checking, backtesting.
